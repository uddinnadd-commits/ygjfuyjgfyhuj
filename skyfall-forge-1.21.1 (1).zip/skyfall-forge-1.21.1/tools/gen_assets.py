import numpy as np, os, json, math, subprocess, random
from PIL import Image, ImageDraw
from scipy import signal
from scipy.io import wavfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = f"{ROOT}/src/main/resources/assets/skyfall"
for d in ["textures/block","textures/item","textures/entity","textures/particle","sounds",
          "models/item","models/block","blockstates","lang","particles"]:
    os.makedirs(f"{A}/{d}", exist_ok=True)

# ---------------------------------------------------------------- noise helpers
def vnoise(w, h, cells, seed):
    g = np.random.default_rng(seed).random((cells, cells))
    xs = np.arange(w) * cells / w; ys = np.arange(h) * cells / h
    x0 = np.floor(xs).astype(int); y0 = np.floor(ys).astype(int)
    fx = xs - x0; fy = ys - y0
    fx = fx*fx*(3-2*fx); fy = fy*fy*(3-2*fy)
    x1 = (x0+1) % cells; y1 = (y0+1) % cells; x0 %= cells; y0 %= cells
    a = g[np.ix_(y0, x0)]; b = g[np.ix_(y0, x1)]; c = g[np.ix_(y1, x0)]; d = g[np.ix_(y1, x1)]
    top = a*(1-fx)[None, :] + b*fx[None, :]
    bot = c*(1-fx)[None, :] + d*fx[None, :]
    return top*(1-fy)[:, None] + bot*fy[:, None]

def fbm(w, h, seed, octs=((2, 1.0), (4, .5), (8, .25))):
    out = np.zeros((h, w)); tot = 0
    for i, (c, a) in enumerate(octs):
        out += vnoise(w, h, c, seed + i*101) * a; tot += a
    return out / tot

def lerp_col(lo, hi, t):
    lo = np.array(lo, float); hi = np.array(hi, float)
    return lo[None, None, :]*(1-t[..., None]) + hi[None, None, :]*t[..., None]

# ---------------------------------------------------------------- block textures (animated, pulsing veins)
PULSE = [0.55, 0.8, 1.0, 0.8]
def flesh_tex(name, lo, hi, vein, seed, style):
    W = H = 16
    n = fbm(W, H, seed)
    n2 = fbm(W, H, seed+7, ((2, 1), (4, .6), (8, .3)))
    if style == "log":
        cols = np.tile(vnoise(16, 1, 8, seed+5), (H, 1))
        n = 0.55*n + 0.45*cols
    if style == "leaves":
        n = fbm(W, H, seed+3, ((4, 1), (8, .7), (16, .35)))
    n = (n - n.min()) / (n.max() - n.min() + 1e-6)
    base = lerp_col(lo, hi, n)
    veins = (np.abs(n2 - 0.5) < (0.045 if style != "leaves" else 0.03))
    if style == "block":
        pores = fbm(W, H, seed+19, ((8, 1), (16, .6))) > 0.68
        base[pores] *= 0.55
    frames = []
    for p in PULSE:
        img = base.copy() * (0.9 + 0.1*p)
        vc = np.array(vein, float) * p
        img[veins] = img[veins]*0.35 + vc*0.65
        frames.append(np.clip(img, 0, 255).astype(np.uint8))
    sheet = np.concatenate(frames, axis=0)
    Image.fromarray(sheet, "RGB").save(f"{A}/textures/block/{name}.png")
    json.dump({"animation": {"frametime": 7, "interpolate": True}},
              open(f"{A}/textures/block/{name}.png.mcmeta", "w"))

flesh_tex("corrupted_ground", (44, 8, 28), (92, 22, 52), (205, 40, 72), 11, "ground")
flesh_tex("flesh_log",        (92, 36, 38), (150, 70, 64), (215, 78, 86), 23, "log")
flesh_tex("flesh_leaves",     (110, 28, 52), (196, 84, 100), (240, 120, 128), 37, "leaves")
flesh_tex("flesh_block",      (150, 78, 76), (208, 132, 122), (150, 36, 62), 41, "block")

# ---------------------------------------------------------------- items
im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
poly = [(8, 0), (12, 4), (11, 9), (14, 14), (7, 15), (3, 10), (5, 4)]
d.polygon(poly, fill=(14, 12, 34, 255))
d.polygon([(8, 2), (11, 5), (9, 9), (6, 6)], fill=(34, 28, 78, 255))
d.polygon([(9, 9), (12, 13), (8, 13)], fill=(22, 44, 92, 255))
d.line(poly + [poly[0]], fill=(150, 222, 255, 255), width=1)
for p in [(8, 1), (12, 5), (6, 5), (13, 13)]:
    im.putpixel(p, (255, 255, 255, 255))
im.save(f"{A}/textures/item/sky_shard.png")

im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
d.rectangle([6, 1, 9, 2], fill=(124, 82, 42, 255))
d.rectangle([6, 3, 9, 4], fill=(196, 232, 246, 255))
body = [(4, 6), (11, 6), (12, 8), (12, 13), (11, 14), (4, 14), (3, 13), (3, 8)]
d.polygon(body, fill=(200, 236, 250, 255))
for y in range(7, 14):
    t = (y-7)/6
    col = (int(120-60*t), int(234-90*t), int(255-25*t), 255)
    d.line([(4, y), (11, y)], fill=col)
d.polygon([(7, 9), (9, 8), (9, 11)], fill=(20, 16, 40, 255))
for p in [(4, 8), (4, 9), (10, 12)]:
    im.putpixel(p, (255, 255, 255, 255))
im.save(f"{A}/textures/item/sky_repellent.png")

# ---------------------------------------------------------------- entity textures
# tentacle 32x16
W, H = 32, 16
n = fbm(W, H, 71, ((2, 1), (4, .6), (8, .3))); n = (n-n.min())/(n.max()-n.min())
img = lerp_col((50, 8, 26), (112, 30, 56), n)
yy, xx = np.mgrid[0:H, 0:W]
for cx in range(2, W, 8):
    for cy in (4, 12):
        r = np.hypot(xx-cx, yy-cy)
        img[r < 2.6] = img[r < 2.6]*0.6 + np.array([205, 120, 128])*0.4
        img[r < 1.2] = np.array([60, 8, 24])
veins = np.abs(fbm(W, H, 77) - 0.5) < 0.04
img[veins] = img[veins]*0.4 + np.array([200, 36, 66])*0.6
Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGB").save(f"{A}/textures/entity/tentacle.png")

def stain(name, coverage, seed, dark, light):
    S = 64
    n = fbm(S, S, seed, ((3, 1), (6, .6), (12, .35), (24, .2)))
    thr = np.quantile(n, 1-coverage)
    alpha = np.clip((n-thr)*16, 0, 1)
    col = lerp_col(dark, light, np.clip((n-thr)*6, 0, 1))
    r = random.Random(seed)
    for _ in range(int(coverage*60)):         # drips
        x = r.randrange(S); y = r.randrange(S); L = r.randrange(3, 9)
        for k in range(L):
            yk = (y+k) % S
            alpha[yk, x] = max(alpha[yk, x], 0.9 - k*0.05)
            col[yk, x] = np.array(dark)
    rgba = np.dstack([np.clip(col, 0, 255), alpha*235]).astype(np.uint8)
    Image.fromarray(rgba, "RGBA").save(f"{A}/textures/entity/{name}.png")

stain("stain_light", 0.22, 5, (24, 2, 8), (96, 14, 24))
stain("stain_heavy", 0.50, 9, (10, 0, 4), (70, 8, 18))
n = fbm(64, 64, 123, ((3, 1), (6, .7), (12, .4)))
v = np.abs(n - 0.5) < 0.03
rgba = np.zeros((64, 64, 4), np.uint8); rgba[v] = (255, 28, 40, 255)
Image.fromarray(rgba, "RGBA").save(f"{A}/textures/entity/stain_glow.png")

# ---------------------------------------------------------------- particle (parasite worm), 3 frames
for f in range(3):
    im = Image.new("RGBA", (8, 8), (0, 0, 0, 0))
    for i in range(7):
        x = i + 0.5; y = 3.5 + 1.6*math.sin(i*0.95 + f*1.15)
        px, py = int(x), int(round(y))
        im.putpixel((px, max(0, min(7, py))), (84, 6, 16, 255))
        if i % 2 == 0:
            im.putpixel((px, max(0, min(7, py-1))), (150, 24, 40, 255))
    hx, hy = 6, max(0, min(7, int(round(3.5 + 1.6*math.sin(6*0.95 + f*1.15)))))
    im.putpixel((hx, hy), (14, 0, 4, 255))
    im.save(f"{A}/textures/particle/parasite_{f}.png")
json.dump({"textures": ["skyfall:parasite_0", "skyfall:parasite_1", "skyfall:parasite_2"]},
          open(f"{A}/particles/parasite.json", "w"), indent=2)

# ---------------------------------------------------------------- json: blockstates / models / lang
for b in ["corrupted_ground", "flesh_log", "flesh_leaves", "flesh_block"]:
    json.dump({"variants": {"": {"model": f"skyfall:block/{b}"}}}, open(f"{A}/blockstates/{b}.json", "w"), indent=2)
    json.dump({"parent": "minecraft:block/cube_all", "textures": {"all": f"skyfall:block/{b}"}},
              open(f"{A}/models/block/{b}.json", "w"), indent=2)
    json.dump({"parent": f"skyfall:block/{b}"}, open(f"{A}/models/item/{b}.json", "w"), indent=2)
for it in ["sky_shard", "sky_repellent"]:
    json.dump({"parent": "minecraft:item/generated", "textures": {"layer0": f"skyfall:item/{it}"}},
              open(f"{A}/models/item/{it}.json", "w"), indent=2)

lang = {
 "item.skyfall.sky_shard": "Sky Shard",
 "item.skyfall.sky_shard.tooltip": "A piece of the broken sky. It is cold to the touch.",
 "item.skyfall.sky_repellent": "Sky Repellent",
 "item.skyfall.sky_repellent.tooltip": "Cleanses corruption, parasites and tentacles nearby.",
 "item.skyfall.sky_repellent.tooltip2": "Right-click. Only lasts a few uses.",
 "block.skyfall.corrupted_ground": "Corrupted Ground",
 "block.skyfall.flesh_log": "Fleshy Log",
 "block.skyfall.flesh_leaves": "Fleshy Growth",
 "block.skyfall.flesh_block": "Corrupted Flesh",
 "entity.skyfall.sky_shard": "Falling Sky Shard",
 "entity.skyfall.sky_tentacle": "Sky Tentacle",
 "itemGroup.skyfall": "The Sky Falls",
 "message.skyfall.nothing_to_cleanse": "There is nothing here to cleanse.",
 "subtitles.skyfall.type_key": "Typewriter clacks",
 "subtitles.skyfall.flesh_squelch": "Flesh squelches",
 "subtitles.skyfall.sky_crack": "The sky cracks",
 "subtitles.skyfall.shard_impact": "Sky shard shatters",
 "subtitles.skyfall.bite": "Parasite-ridden creature bites",
 "subtitles.skyfall.cleanse": "Corruption is cleansed",
 "subtitles.skyfall.tentacle_grab": "Tentacle seizes",
}
json.dump(lang, open(f"{A}/lang/en_us.json", "w"), indent=2)

# ---------------------------------------------------------------- sounds (numpy synth -> mono ogg)
SR = 44100
rs = np.random.default_rng(99)
def T(sec): return np.arange(int(SR*sec)) / SR
def lp(x, fc, order=4): return signal.sosfilt(signal.butter(order, fc, "low", fs=SR, output="sos"), x)
def hp(x, fc, order=4): return signal.sosfilt(signal.butter(order, fc, "high", fs=SR, output="sos"), x)
def bp(x, lo, hi, order=3): return signal.sosfilt(signal.butter(order, [lo, hi], "band", fs=SR, output="sos"), x)
def noise(n): return rs.standard_normal(n)
def norm(x, peak=0.85):
    x = x - np.mean(x); return x / (np.max(np.abs(x)) + 1e-9) * peak
def place(buf, snd, at):
    i = int(at*SR); j = min(len(buf), i+len(snd)); buf[i:j] += snd[:j-i]
def ring(freq, dur, amp=1.0, decay=40):
    t = T(dur); return amp*np.sin(2*np.pi*freq*t)*np.exp(-t*decay)
def save_ogg(name, x):
    wav = f"/tmp/{name}.wav"
    wavfile.write(wav, SR, (np.clip(x, -1, 1)*32767).astype(np.int16))
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-c:a", "libvorbis", "-q:a", "4",
                    f"{A}/sounds/{name}.ogg"], check=True)

# typewriter key
t = T(0.09)
click = bp(noise(len(t)), 1500, 6000)*np.exp(-t*220) + 0.5*np.sin(2*np.pi*130*t)*np.exp(-t*90) + 0.25*np.sin(2*np.pi*2400*t)*np.exp(-t*110)
save_ogg("type_key", norm(click, 0.7))

# flesh squelch x3
def squelch(seed, dur=0.5, f0=190):
    r = np.random.default_rng(seed); t = T(dur)
    nz = lp(r.standard_normal(len(t)), 900)
    bub = (0.5 + 0.5*np.sin(2*np.pi*(26+r.random()*18)*t + r.random()*6))**2
    body = nz*bub*np.exp(-t*6.5)
    f = f0*np.exp(-3.2*t) + 48
    chirp = np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*7)*0.7
    slap = bp(r.standard_normal(len(t)), 300, 1800)*np.exp(-t*160)*1.3
    return norm(body*2.2 + chirp + slap, 0.85)
for i, (sd, f0) in enumerate([(1, 190), (2, 150), (3, 230)], 1):
    save_ogg(f"flesh_squelch{i}", squelch(sd, 0.5, f0))

# sky crack (rumble + glass cracks + reversed shimmer)
dur = 3.2; t = T(dur); buf = np.zeros(len(t))
rumble = lp(noise(len(t)), 110)*(np.sin(np.pi*np.clip(t/dur, 0, 1))**1.5)
buf += rumble*5 + np.sin(2*np.pi*38*t)*np.exp(-t*1.1)*0.9
for at in [0.12, 0.34, 0.47, 0.93, 1.4]:
    crack = hp(noise(int(0.25*SR)), 2500)*np.exp(-T(0.25)*38)
    for fq in (rs.uniform(3000, 9000), rs.uniform(3000, 9000)):
        crack += ring(fq, 0.25, 0.35, 30)
    place(buf, crack*rs.uniform(0.5, 1.0), at)
shim = (hp(noise(int(1.2*SR)), 3500)*np.sin(np.linspace(0, np.pi, int(1.2*SR)))**3)[::-1]*0.5
place(buf, shim[::-1] if False else shim, 0.0)
save_ogg("sky_crack", norm(buf, 0.9))

# shard impact (shatter + thud)
dur = 2.0; t = T(dur); buf = np.zeros(len(t))
for _ in range(90):
    at = abs(rs.normal(0, 0.45)); at = min(at, dur-0.2)
    place(buf, ring(rs.uniform(2200, 9500), 0.16, rs.uniform(0.15, 0.5), rs.uniform(30, 70)), at)
buf += lp(noise(len(t)), 500)*np.exp(-t*7)*2.2 + np.sin(2*np.pi*55*t)*np.exp(-t*5)*1.1
buf += hp(noise(len(t)), 3000)*np.exp(-t*14)*0.7
save_ogg("shard_impact", norm(buf, 0.92))

# bite (crunch)
dur = 0.4; t = T(dur); buf = np.zeros(len(t))
for at in (0.0, 0.045, 0.1):
    place(buf, bp(noise(int(0.06*SR)), 700, 3200)*np.exp(-T(0.06)*60)*1.4, at)
buf += squelch(7, dur, 160)*0.5
save_ogg("bite", norm(buf, 0.9))

# cleanse chime
dur = 2.0; t = T(dur); buf = np.zeros(len(t))
for k, fq in enumerate([880, 1318.5, 1760, 2637, 3520]):
    place(buf, ring(fq, dur-k*0.05, 1.0/(k+1), 2.6+k*0.5), k*0.05)
echo = buf.copy()
for dly, g in ((0.11, 0.45), (0.23, 0.3), (0.37, 0.18)):
    place(echo, buf*g, dly)
save_ogg("cleanse", norm(echo[:len(t)], 0.7))

# tentacle grab groan
dur = 1.5; t = T(dur)
f = 90*np.exp(-0.9*t) + 38
mod = np.sin(2*np.pi*6*t)*(6 + 10*t)
groan = np.sin(2*np.pi*np.cumsum(f)/SR + mod)
env = np.minimum(t/0.15, 1)*np.exp(-t*1.4)
buf = groan*env*0.9 + lp(noise(len(t)), 260)*env*1.8
place(buf, squelch(12, 0.5, 120)*0.9, 0.0)
save_ogg("tentacle_grab", norm(buf, 0.9))

# sounds.json
sj = {
 "type_key":      {"subtitle": "subtitles.skyfall.type_key",      "sounds": [{"name": "skyfall:type_key", "volume": 0.5}]},
 "flesh_squelch": {"subtitle": "subtitles.skyfall.flesh_squelch", "sounds": ["skyfall:flesh_squelch1", "skyfall:flesh_squelch2", "skyfall:flesh_squelch3"]},
 "sky_crack":     {"subtitle": "subtitles.skyfall.sky_crack",     "sounds": [{"name": "skyfall:sky_crack", "attenuation_distance": 256}]},
 "shard_impact":  {"subtitle": "subtitles.skyfall.shard_impact",  "sounds": [{"name": "skyfall:shard_impact", "attenuation_distance": 128}]},
 "bite":          {"subtitle": "subtitles.skyfall.bite",          "sounds": ["skyfall:bite"]},
 "cleanse":       {"subtitle": "subtitles.skyfall.cleanse",       "sounds": ["skyfall:cleanse"]},
 "tentacle_grab": {"subtitle": "subtitles.skyfall.tentacle_grab", "sounds": ["skyfall:tentacle_grab"]},
}
json.dump(sj, open(f"{A}/sounds.json", "w"), indent=2)

# contact sheet for eyeballing
sheet = Image.new("RGBA", (16*8*4+20, 16*8*3), (40, 40, 40, 255))
def paste(path, x, y, scale=8, frame0=True):
    im = Image.open(path).convert("RGBA")
    if frame0 and im.height > im.width*2 and "textures/block" in path: im = im.crop((0, 0, 16, 16))
    im = im.resize((im.width*scale, im.height*scale), Image.NEAREST); sheet.alpha_composite(im, (x, y))
paste(f"{A}/textures/block/corrupted_ground.png", 0, 0)
paste(f"{A}/textures/block/flesh_log.png", 130, 0)
paste(f"{A}/textures/block/flesh_leaves.png", 260, 0)
paste(f"{A}/textures/block/flesh_block.png", 390, 0)
paste(f"{A}/textures/item/sky_shard.png", 0, 130)
paste(f"{A}/textures/item/sky_repellent.png", 130, 130)
paste(f"{A}/textures/entity/tentacle.png", 260, 130, 4)
paste(f"{A}/textures/entity/stain_light.png", 0, 260, 3)
paste(f"{A}/textures/entity/stain_heavy.png", 200, 260, 3)
paste(f"{A}/textures/entity/stain_glow.png", 400, 260, 3)
sheet.save("/tmp/skyfall_contact.png")
print("assets ok")
