# The Sky Falls (Forge 1.21.1)

A horror mod. The sky is breaking, and something is coming through.

## Build it

I could not compile this in my sandbox (no network), so it is source only. To build:

1. Download the **Forge 1.21.1 MDK** from https://files.minecraftforge.net (any 52.x build) and unzip it.
2. Delete the MDK's `src/` folder and copy this project's `src/` folder in its place.
3. In the MDK's `gradle.properties` change only the mod keys (see `gradle.properties.example`): `mod_id=skyfall`, `mod_name`, `mod_group_id=com.skyfall`, etc.
   Leave `minecraft_version`, `forge_version` and the mapping keys alone. `mod_id` **must** be `skyfall`.
4. Needs JDK 21. Run `./gradlew build` (jar ends up in `build/libs/`) or `./gradlew runClient` to test.

If the compiler complains about an API name, it is almost certainly a one-line fix. Send me the error.

## Phases

| Phase | Trigger | What happens |
|---|---|---|
| 1 | 1+ shards | A hole opens in the sky, a shard peels off and falls. "The sky falls again." types on your hotbar. Passive mobs flee falling shards and twitch. |
| 2 | 5+ shards | Passive mobs get dark stains, sometimes rush you and bite. Parasites crawl around tree trunks. Horizon turns dark red. |
| 3 | 15+ shards | Infected mobs hunt you constantly. Corruption spreads over ground, trees (fleshy, squishy, bouncy leaves) and houses, with a squelch each time. Touching it gives Wither. Tentacles reach down from the holes and try to grab you. Shards corrupt the ground where they land. |

## Sky Repellent

`Glowstone Dust, Sky Shard, Glowstone Dust` over `Glass Bottle` (bottle in the middle of row 2). 10 durability.
Right-click: restores corrupted blocks (to exactly what they were), cures infected animals (and makes them immune),
banishes nearby tentacles, and cures your Wither. It costs durability only if it actually cleansed something.
Sky Shards drop when a shard lands (1-2), and sometimes from killed tentacles.

## SKY

A guide who fell from the sky. Looks like a player (player model, your skin file `textures/entity/sky.png`, wide arms).

- **Arrival:** when the 10th shard falls (between phase 2 and phase 3) "SKY joined the game" appears in chat, she sends a few
  lowercase chat lines (the third one gives her coordinates), and she appears about 20 blocks from a player.
  She is a real entity, not a fake player, so she will not show in the tab list.
- **Waiting:** frantic. Paces, wrings her hands, snaps her head around, keeps staring up at the sky.
- **Cutscene:** walk within ~5 blocks and it starts (letterbox bars, typed subtitles with a cold voice blip, camera tracks her).
  She talks for about 22 seconds, walks up and reaches for your shoulder, then a tentacle lowers out of the sky behind her.
  She is cut off mid-sentence, seized, and dragged up into the void. She drops 2 Sky Shards. About 5 seconds after the
  cutscene the next shard falls. It only ever plays once per world.
- Everyone within 24 blocks sees the cutscene. You are untouchable while it runs (hidden Resistance V).
- Her animations (idle, talk, reach, grabbed) are in `SkyModel.java`; the timeline is the constants at the top of `SkyStory.java`;
  her lines are `dialogue.skyfall.sky.0-6` in `lang/en_us.json`.

## Commands (OP level 2)

`/skyfall status` | `/skyfall drop` | `/skyfall phase <0-3>` | `/skyfall set <count>` | `/skyfall tentacle` | `/skyfall sky` (spawn SKY next to you, replayable) | `/skyfall reset` (also resets SKY)

Quick test: `/skyfall phase 3`, then `/skyfall drop`, look up.

## Config (`config/skyfall-common.toml`)

Shard interval (default 2.5 to 7.5 minutes), and toggles for mob infection, corruption and tentacles.

## Notes

- Everything only happens in the Overworld.
- Tamed pets and tamed horses are never infected.
- `tools/gen_assets.py` regenerates all textures and sounds (numpy, Pillow, scipy, ffmpeg).
- Infection is stored in the vanilla-synced air-supply value (air > max air), so no extra packets are needed.
