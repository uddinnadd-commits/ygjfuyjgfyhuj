package com.skyfall;

import com.mojang.logging.LogUtils;
import com.skyfall.network.Net;
import com.skyfall.registry.ModBlockEntities;
import com.skyfall.registry.ModBlocks;
import com.skyfall.registry.ModEntities;
import com.skyfall.registry.ModItems;
import com.skyfall.registry.ModParticles;
import com.skyfall.registry.ModSounds;
import com.skyfall.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * "The Sky Falls" - a horror mod about a sky that is slowly breaking.
 * Phase 1 (1+ shards): mobs flee shards and twitch.
 * Phase 2 (5+ shards): passive mobs are stained and sometimes rush/bite, parasites crawl on trees.
 * Phase 3 (15+ shards): hostile hosts, fleshy trees, spreading corruption (Wither), sky tentacles.
 */
@Mod(SkyfallMod.MODID)
public class SkyfallMod {
    public static final String MODID = "skyfall";
    public static final Logger LOGGER = LogUtils.getLogger();

    public SkyfallMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModParticles.PARTICLES.register(modBus);
        ModTabs.TABS.register(modBus);
        Net.register();
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, SkyfallConfig.SPEC);
    }
}
