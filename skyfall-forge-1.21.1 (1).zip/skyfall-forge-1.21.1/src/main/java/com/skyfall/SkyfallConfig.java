package com.skyfall;

import net.minecraftforge.common.ForgeConfigSpec;

public final class SkyfallConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue SHARD_MIN_TICKS;
    public static final ForgeConfigSpec.IntValue SHARD_MAX_TICKS;
    public static final ForgeConfigSpec.BooleanValue ENABLE_MOB_INFECTION;
    public static final ForgeConfigSpec.BooleanValue ENABLE_CORRUPTION;
    public static final ForgeConfigSpec.BooleanValue ENABLE_TENTACLES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("sky");
        SHARD_MIN_TICKS = b.comment("Minimum ticks between shards falling (20 ticks = 1 second). Default 3000 = 2.5 minutes.")
                .defineInRange("shardMinTicks", 3000, 20, 100_000_000);
        SHARD_MAX_TICKS = b.comment("Maximum ticks between shards falling. Default 9000 = 7.5 minutes.")
                .defineInRange("shardMaxTicks", 9000, 20, 100_000_000);
        b.pop();
        b.push("phases");
        ENABLE_MOB_INFECTION = b.comment("Phase 2+: passive mobs get parasites (stains, biting, hostility).")
                .define("enableMobInfection", true);
        ENABLE_CORRUPTION = b.comment("Phase 3: the ground, trees and houses get corrupted.")
                .define("enableCorruption", true);
        ENABLE_TENTACLES = b.comment("Phase 3: tentacles reach down from the broken sky.")
                .define("enableTentacles", true);
        b.pop();
        SPEC = b.build();
    }

    private SkyfallConfig() {}
}
