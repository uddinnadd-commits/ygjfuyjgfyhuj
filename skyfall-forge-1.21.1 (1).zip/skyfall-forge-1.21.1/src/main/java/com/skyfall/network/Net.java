package com.skyfall.network;

import com.skyfall.SkyfallMod;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.SimpleChannel;

public final class Net {
    private static final int PROTOCOL_VERSION = 1;

    public static final SimpleChannel CHANNEL = ChannelBuilder
            .named(ResourceLocation.fromNamespaceAndPath(SkyfallMod.MODID, "main"))
            .networkProtocolVersion(PROTOCOL_VERSION)
            .simpleChannel();

    public static void register() {
        CHANNEL.messageBuilder(SkySyncPacket.class)
                .direction(PacketFlow.CLIENTBOUND)
                .encoder(SkySyncPacket::encode)
                .decoder(SkySyncPacket::decode)
                .consumerMainThread(SkySyncPacket::handle)
                .add();
        CHANNEL.messageBuilder(SkyCutscenePacket.class)
                .direction(PacketFlow.CLIENTBOUND)
                .encoder(SkyCutscenePacket::encode)
                .decoder(SkyCutscenePacket::decode)
                .consumerMainThread(SkyCutscenePacket::handle)
                .add();
    }

    public static void sendTo(ServerPlayer player, Object packet) {
        CHANNEL.send(packet, player.connection.getConnection());
    }

    private Net() {}
}
