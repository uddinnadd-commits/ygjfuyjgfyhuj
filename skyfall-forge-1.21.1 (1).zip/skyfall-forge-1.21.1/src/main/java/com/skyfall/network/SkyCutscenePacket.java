package com.skyfall.network;

import com.skyfall.client.ClientCutscene;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server -> client: drives SKY's cutscene (the server owns the timeline, the client shows it). */
public record SkyCutscenePacket(int action, int entityId, int arg) {
    public static final int START = 0;    // entityId = SKY
    public static final int LINE = 1;     // arg = dialogue line index
    public static final int TOUCH = 2;    // her hand lands on your shoulder
    public static final int CUTOFF = 3;   // the tentacle hits: cut the current line off
    public static final int FADE = 4;     // she is gone: fade to black
    public static final int STOP = 5;     // end the cutscene

    public static void encode(SkyCutscenePacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.action);
        buf.writeInt(p.entityId);
        buf.writeVarInt(p.arg);
    }

    public static SkyCutscenePacket decode(FriendlyByteBuf buf) {
        return new SkyCutscenePacket(buf.readVarInt(), buf.readInt(), buf.readVarInt());
    }

    public static void handle(SkyCutscenePacket p, CustomPayloadEvent.Context ctx) {
        ClientCutscene.handle(p.action, p.entityId, p.arg);
    }
}
