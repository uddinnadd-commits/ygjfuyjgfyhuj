package com.skyfall.network;

import com.skyfall.client.ClientSkyState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.event.network.CustomPayloadEvent;

/** Server -> client: how many shards have fallen, and the seed that decides where the holes are. */
public record SkySyncPacket(int count, long seed, boolean animate) {

    public static void encode(SkySyncPacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.count);
        buf.writeLong(p.seed);
        buf.writeBoolean(p.animate);
    }

    public static SkySyncPacket decode(FriendlyByteBuf buf) {
        return new SkySyncPacket(buf.readVarInt(), buf.readLong(), buf.readBoolean());
    }

    public static void handle(SkySyncPacket p, CustomPayloadEvent.Context ctx) {
        ClientSkyState.update(p.count, p.seed, p.animate);
    }
}
