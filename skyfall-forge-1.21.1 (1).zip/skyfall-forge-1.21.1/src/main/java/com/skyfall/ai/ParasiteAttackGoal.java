package com.skyfall.ai;

import com.skyfall.Infection;
import com.skyfall.registry.ModSounds;
import com.skyfall.world.SkyfallManager;
import java.util.EnumSet;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;

/**
 * Infected animals rush the nearest player and bite.
 * Phase 2: only sometimes, only if they can see you. Phase 3: relentlessly, from far away.
 */
public class ParasiteAttackGoal extends Goal {
    private final Animal mob;
    private Player target;
    private int rushTicks;
    private int attackCooldown;
    private int pathDelay;
    private int restTicks;

    public ParasiteAttackGoal(Animal mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public boolean canUse() {
        if (!Infection.isInfected(this.mob) || this.mob.isPassenger()) return false;
        int phase = SkyfallManager.phase();
        if (phase < 2) return false;
        if (restTicks > 0) {
            restTicks--;
            return false;
        }
        RandomSource r = this.mob.getRandom();
        if (phase == 2 && r.nextInt(70) != 0) return false;
        double range = phase >= 3 ? 32.0 : 14.0;
        Player p = this.mob.level().getNearestPlayer(this.mob.getX(), this.mob.getY(), this.mob.getZ(), range,
                EntitySelector.NO_CREATIVE_OR_SPECTATOR);
        if (p == null) return false;
        if (phase == 2 && !this.mob.hasLineOfSight(p)) return false;
        this.target = p;
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && !target.isCreative() && !target.isSpectator()
                && rushTicks > 0 && Infection.isInfected(this.mob) && this.mob.distanceToSqr(target) < 48.0 * 48.0;
    }

    @Override
    public void start() {
        RandomSource r = this.mob.getRandom();
        rushTicks = SkyfallManager.phase() >= 3 ? 400 : 70 + r.nextInt(60);
        attackCooldown = 10;
        pathDelay = 0;
    }

    @Override
    public void tick() {
        rushTicks--;
        attackCooldown--;
        this.mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (--pathDelay <= 0) {
            pathDelay = 4 + this.mob.getRandom().nextInt(4);
            this.mob.getNavigation().moveTo(target, SkyfallManager.phase() >= 3 ? 1.5 : 1.35);
        }
        double reach = (this.mob.getBbWidth() * 2.0F) * (this.mob.getBbWidth() * 2.0F) + target.getBbWidth();
        if (attackCooldown <= 0 && this.mob.distanceToSqr(target.getX(), target.getY(), target.getZ()) <= reach) {
            attackCooldown = 20;
            bite();
        }
    }

    private void bite() {
        this.mob.swing(InteractionHand.MAIN_HAND);
        float damage = SkyfallManager.phase() >= 3 ? 4.0F : 2.0F;
        if (target.hurt(this.mob.damageSources().mobAttack(this.mob), damage)) {
            target.knockback(0.4, this.mob.getX() - target.getX(), this.mob.getZ() - target.getZ());
            this.mob.level().playSound(null, this.mob.blockPosition(), ModSounds.BITE.get(), SoundSource.HOSTILE,
                    1.0F, 0.8F + this.mob.getRandom().nextFloat() * 0.4F);
        }
    }

    @Override
    public void stop() {
        this.mob.getNavigation().stop();
        restTicks = SkyfallManager.phase() >= 3 ? 5 : 60 + this.mob.getRandom().nextInt(140);
        target = null;
    }
}
