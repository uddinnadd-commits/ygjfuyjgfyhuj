package com.skyfall.ai;

import com.skyfall.Infection;
import com.skyfall.entity.SkyShardEntity;
import com.skyfall.world.SkyfallManager;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

/** Phase 1: passive mobs run away from falling shards. */
public class ShardFleeGoal extends Goal {
    private final PathfinderMob mob;
    private SkyShardEntity shard;
    private Vec3 destination;
    private int scanDelay;

    public ShardFleeGoal(PathfinderMob mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (SkyfallManager.phase() < 1 || Infection.isInfected(this.mob)) return false;
        if (--scanDelay > 0) return false;
        scanDelay = 4;
        List<SkyShardEntity> shards = this.mob.level().getEntitiesOfClass(SkyShardEntity.class,
                this.mob.getBoundingBox().inflate(30.0, 120.0, 30.0));
        SkyShardEntity best = null;
        double bestDist = 28.0 * 28.0;
        for (SkyShardEntity s : shards) {
            double dx = s.getX() - this.mob.getX();
            double dz = s.getZ() - this.mob.getZ();
            double d = dx * dx + dz * dz;
            if (d < bestDist) {
                bestDist = d;
                best = s;
            }
        }
        if (best == null) return false;
        Vec3 away = DefaultRandomPos.getPosAway(this.mob, 18, 7, best.position());
        if (away == null) return false;
        this.shard = best;
        this.destination = away;
        return true;
    }

    @Override
    public void start() {
        this.mob.getNavigation().moveTo(destination.x, destination.y, destination.z, 1.75);
    }

    @Override
    public boolean canContinueToUse() {
        return shard != null && shard.isAlive() && !this.mob.getNavigation().isDone();
    }

    @Override
    public void stop() {
        shard = null;
    }
}
