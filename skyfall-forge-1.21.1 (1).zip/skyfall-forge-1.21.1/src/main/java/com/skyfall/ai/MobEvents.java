package com.skyfall.ai;

import com.skyfall.SkyfallMod;
import net.minecraft.world.entity.ai.goal.WrappedGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Gives every passive animal the three "sky is breaking" behaviours when it enters the world. */
@Mod.EventBusSubscriber(modid = SkyfallMod.MODID)
public final class MobEvents {

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof Animal animal)) return;
        for (WrappedGoal g : animal.goalSelector.getAvailableGoals()) {
            if (g.getGoal() instanceof ParasiteHostGoal) return;   // already set up
        }
        animal.goalSelector.addGoal(0, new ParasiteHostGoal(animal));
        animal.goalSelector.addGoal(0, new ShardFleeGoal(animal));
        animal.goalSelector.addGoal(0, new ParasiteAttackGoal(animal));
    }

    private MobEvents() {}
}
