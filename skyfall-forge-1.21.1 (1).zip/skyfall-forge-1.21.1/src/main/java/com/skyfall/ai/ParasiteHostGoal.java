package com.skyfall.ai;

import com.skyfall.Infection;
import com.skyfall.SkyfallConfig;
import com.skyfall.entity.SkyShardEntity;
import com.skyfall.world.SkyfallManager;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.level.Level;

/**
 * Runs on every passive mob (no goal flags, so it never blocks other AI).
 * - phase 1+: twitching, especially while a shard is falling nearby
 * - phase 2+: the mob becomes a parasite host (the client draws stains on it)
 */
public class ParasiteHostGoal extends Goal {
    private final Animal mob;
    private int twitchTicks;
    private int scanDelay;

    public ParasiteHostGoal(Animal mob) {
        this.mob = mob;
    }

    @Override
    public boolean canUse() {
        return this.mob.level().dimension() == Level.OVERWORLD;
    }

    @Override
    public boolean canContinueToUse() {
        return true;
    }

    private boolean isPet() {
        return (this.mob instanceof TamableAnimal t && t.isTame()) || (this.mob instanceof AbstractHorse h && h.isTamed());
    }

    @Override
    public void tick() {
        int phase = SkyfallManager.phase();
        RandomSource r = this.mob.getRandom();

        boolean host = phase >= 2 && SkyfallConfig.ENABLE_MOB_INFECTION.get() && !Infection.isImmune(this.mob) && !isPet();
        Infection.setInfected(this.mob, host);

        if (phase < 1) return;
        if (--scanDelay <= 0) {
            scanDelay = 10 + r.nextInt(10);
            boolean shardNear = !this.mob.level().getEntitiesOfClass(SkyShardEntity.class,
                    this.mob.getBoundingBox().inflate(48.0, 110.0, 48.0)).isEmpty();
            if (shardNear) {
                twitchTicks = Math.max(twitchTicks, 120);
            } else if (r.nextInt(host ? 25 : 90) == 0) {
                twitchTicks = Math.max(twitchTicks, 12 + r.nextInt(30));
            }
        }
        if (twitchTicks > 0) {
            twitchTicks -= 2;
            if (r.nextInt(3) != 0) jerk(r);
        }
    }

    /** One twitch: a sudden snap of the head and body, sometimes a little spasm hop. */
    private void jerk(RandomSource r) {
        float yaw = this.mob.getYRot() + (r.nextFloat() - 0.5F) * 70.0F;
        this.mob.setYRot(yaw);
        this.mob.yRotO = yaw;
        this.mob.yBodyRot = yaw;
        this.mob.yBodyRotO = yaw;
        this.mob.yHeadRot = yaw + (r.nextFloat() - 0.5F) * 50.0F;
        this.mob.yHeadRotO = this.mob.yHeadRot;
        float pitch = (r.nextFloat() - 0.5F) * 60.0F;
        this.mob.setXRot(pitch);
        this.mob.xRotO = pitch;
        if (this.mob.onGround() && r.nextInt(4) == 0) {
            this.mob.setDeltaMovement(this.mob.getDeltaMovement().add((r.nextFloat() - 0.5F) * 0.14, 0.12, (r.nextFloat() - 0.5F) * 0.14));
        }
    }
}
