package com.skyfall.entity;

import com.skyfall.Phases;
import com.skyfall.SkyfallConfig;
import com.skyfall.registry.ModItems;
import com.skyfall.registry.ModSounds;
import com.skyfall.world.Corruption;
import com.skyfall.world.SkyfallManager;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

/** A piece of broken sky, falling. Rendered as a glassy polygon (see SkyShardRenderer). */
public class SkyShardEntity extends Entity {
    private static final EntityDataAccessor<Integer> DATA_SEED = SynchedEntityData.defineId(SkyShardEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_SIZE = SynchedEntityData.defineId(SkyShardEntity.class, EntityDataSerializers.FLOAT);

    private boolean impacted;

    public SkyShardEntity(EntityType<? extends SkyShardEntity> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_SEED, 0);
        builder.define(DATA_SIZE, 2.0F);
    }

    public void randomize(RandomSource r) {
        this.entityData.set(DATA_SEED, r.nextInt());
        this.entityData.set(DATA_SIZE, 1.5F + r.nextFloat() * 2.3F);
    }

    public int getShardSeed() {
        return this.entityData.get(DATA_SEED);
    }

    public float getShardSize() {
        return this.entityData.get(DATA_SIZE);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 640.0 * 640.0;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        Vec3 v = this.getDeltaMovement();
        v = new Vec3(v.x * 0.995, Math.max(v.y - 0.045, -2.0), v.z * 0.995);
        this.setDeltaMovement(v);
        this.move(MoverType.SELF, v);

        if (this.level().isClientSide) {
            clientTrail();
            return;
        }
        if (!impacted && (this.onGround() || this.verticalCollision || this.horizontalCollision)) {
            impact();
        }
        if (this.tickCount > 1200 || this.getY() < this.level().getMinBuildHeight() - 10) {
            this.discard();
        }
    }

    private void clientTrail() {
        if (this.tickCount % 2 != 0) return;
        double w = getShardSize() * 0.4;
        level().addParticle(ParticleTypes.END_ROD,
                getX() + (random.nextDouble() - 0.5) * w, getY() + 0.6, getZ() + (random.nextDouble() - 0.5) * w,
                0.0, 0.04, 0.0);
        level().addParticle(ParticleTypes.SMOKE,
                getX() + (random.nextDouble() - 0.5) * w, getY() + 0.6, getZ() + (random.nextDouble() - 0.5) * w,
                0.0, 0.02, 0.0);
    }

    private void impact() {
        impacted = true;
        if (!(this.level() instanceof ServerLevel sl)) return;
        double x = getX(), y = getY(), z = getZ();
        sl.playSound(null, x, y, z, ModSounds.SHARD_IMPACT.get(), SoundSource.AMBIENT, 6.0F, 0.85F + sl.random.nextFloat() * 0.3F);
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.GLASS.defaultBlockState()),
                x, y + 0.3, z, 70, 0.9, 0.5, 0.9, 0.35);
        sl.sendParticles(ParticleTypes.END_ROD, x, y + 0.3, z, 30, 0.6, 0.6, 0.6, 0.12);

        for (LivingEntity le : sl.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(2.5))) {
            le.hurt(this.damageSources().magic(), 8.0F);
        }
        this.spawnAtLocation(new ItemStack(ModItems.SKY_SHARD.get(), 1 + this.random.nextInt(2)));

        if (Phases.of(SkyfallManager.shardCount()) >= 3 && SkyfallConfig.ENABLE_CORRUPTION.get()) {
            Corruption.corruptBlob(sl, this.blockPosition().below(), 3, 40);
        }
        this.discard();
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {}

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {}
}
