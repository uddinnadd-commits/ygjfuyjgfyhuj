package com.skyfall.entity;

import com.skyfall.story.SkyStory;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * SKY. A guide who fell from the sky. Looks like a player (the renderer uses the player model and her skin).
 * The state drives her custom animations (see SkyModel); the cutscene script (SkyStory) switches the states.
 */
public class SkyNpcEntity extends PathfinderMob {
    public static final int IDLE = 0;      // frantic: pacing, twitching, staring at the sky
    public static final int TALK = 1;      // cold, sharp gestures
    public static final int REACH = 2;     // walking up to you, reaching for your shoulder
    public static final int GRABBED = 3;   // seized by the tentacle

    private static final EntityDataAccessor<Integer> DATA_STATE = SynchedEntityData.defineId(SkyNpcEntity.class, EntityDataSerializers.INT);

    private int animTicks;
    private int lastClientState = -1;
    private BlockPos home;

    public SkyNpcEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setCustomName(Component.literal("SKY"));
        this.setCustomNameVisible(true);
        this.setPersistenceRequired();
        this.setInvulnerable(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_STATE, IDLE);
    }

    public int getState() {
        return this.entityData.get(DATA_STATE);
    }

    public void setState(int state) {
        this.entityData.set(DATA_STATE, state);
    }

    /** Client-side: ticks since the current animation state began (used by the model). */
    public int getAnimTicks() {
        return animTicks;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            int s = getState();
            if (s != lastClientState) {
                lastClientState = s;
                animTicks = 0;
            } else {
                animTicks++;
            }
        }
    }

    @Override
    protected void registerGoals() {
        // scripted below / by SkyStory
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (getState() != IDLE && !SkyStory.isActiveFor(this)) {
            // stale state (the world was reloaded mid-cutscene): go back to waiting
            setState(IDLE);
            this.setNoGravity(false);
            this.noPhysics = false;
        }
        if (getState() == IDLE) idleBehaviour();
    }

    private void idleBehaviour() {
        if (home == null) home = this.blockPosition();
        RandomSource r = this.getRandom();
        Player near = this.level().getNearestPlayer(getX(), getY(), getZ(), 24.0, EntitySelector.NO_SPECTATORS);

        if (near != null && (this.tickCount / 25) % 3 != 2) {
            this.getLookControl().setLookAt(near, 40.0F, 40.0F);
        } else {
            // staring up at the sky, slowly turning, like she is waiting for something
            this.getLookControl().setLookAt(getX() + Math.sin(this.tickCount * 0.05) * 6.0, getEyeY() + 30.0,
                    getZ() + Math.cos(this.tickCount * 0.05) * 6.0);
        }

        // frantic pacing around where she arrived
        if (this.getNavigation().isDone() && r.nextInt(16) == 0) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double d = 2.0 + r.nextDouble() * 4.0;
            this.getNavigation().moveTo(home.getX() + 0.5 + Math.cos(a) * d, home.getY(), home.getZ() + 0.5 + Math.sin(a) * d,
                    1.1 + r.nextDouble() * 0.5);
        }

        // walk up to her -> the cutscene starts
        Player trigger = this.level().getNearestPlayer(getX(), getY(), getZ(), 5.5, EntitySelector.NO_SPECTATORS);
        if (trigger instanceof ServerPlayer sp && this.hasLineOfSight(sp) && this.level() instanceof ServerLevel sl) {
            SkyStory.begin(sl, this, sp);
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }
}
