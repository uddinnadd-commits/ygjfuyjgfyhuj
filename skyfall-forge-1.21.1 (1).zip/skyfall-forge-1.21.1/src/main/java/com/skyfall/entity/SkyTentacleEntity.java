package com.skyfall.entity;

import com.skyfall.registry.ModItems;
import com.skyfall.registry.ModSounds;
import com.skyfall.world.SkyfallManager;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A tentacle reaching down from a hole in the broken sky. The entity itself is only the TIP; the renderer draws the
 * rope from the tip up along {@link #getSkyDirection()}. It chases a player, grabs, lifts and hurts them, then retracts.
 * Hit it to make it let go. The Sky Repellent banishes it.
 */
public class SkyTentacleEntity extends Monster {
    public static final float LENGTH = 150.0F;
    public static final int EXTEND_TICKS = 50;
    private static final int HOLD_TICKS = 40;

    private static final EntityDataAccessor<Float> DIR_X = SynchedEntityData.defineId(SkyTentacleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DIR_Y = SynchedEntityData.defineId(SkyTentacleEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DIR_Z = SynchedEntityData.defineId(SkyTentacleEntity.class, EntityDataSerializers.FLOAT);

    private UUID grabbed;
    private int grabTicks;
    private int grabCooldown;
    private int retractTicks = -1;
    private int life;
    /** Cutscene mode: no AI, no despawning, cannot be hurt. The cutscene script moves it. */
    private boolean scripted;

    public SkyTentacleEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
        this.noCulling = true;
        this.xpReward = 5;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DIR_X, 0.0F);
        builder.define(DIR_Y, 1.0F);
        builder.define(DIR_Z, 0.0F);
    }

    @Override
    protected void registerGoals() {
        // no vanilla AI: movement is scripted in aiStep()
    }

    public void setSkyDirection(Vec3 dir) {
        Vec3 n = dir.normalize();
        this.entityData.set(DIR_X, (float) n.x);
        this.entityData.set(DIR_Y, (float) n.y);
        this.entityData.set(DIR_Z, (float) n.z);
    }

    public Vec3 getSkyDirection() {
        return new Vec3(this.entityData.get(DIR_X), this.entityData.get(DIR_Y), this.entityData.get(DIR_Z));
    }

    /** 0 -> 1 while the tentacle lowers itself out of the sky. */
    public float getReach(float partialTick) {
        float t = Mth.clamp((this.tickCount + partialTick) / EXTEND_TICKS, 0.0F, 1.0F);
        return 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
    }

    /* ------------------------------------------------------------------ behaviour */

    public void setScripted(boolean scripted) {
        this.scripted = scripted;
        this.noPhysics = scripted;
        if (scripted) this.setPersistenceRequired();
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide && !scripted) serverThink();
        super.aiStep();
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return !scripted;
    }

    private void serverThink() {
        life++;
        if (SkyfallManager.phase() < 3 || life > 1400) {
            vanish();
            return;
        }
        if (grabCooldown > 0) grabCooldown--;

        if (retractTicks >= 0) {
            retractTicks++;
            this.setDeltaMovement(getSkyDirection().scale(0.9));
            if (retractTicks > 40) vanish();
            return;
        }
        if (this.tickCount < EXTEND_TICKS) {
            this.setDeltaMovement(Vec3.ZERO);
            return;
        }

        Player held = getGrabbed();
        if (held != null) {
            hold(held);
            return;
        }

        Player target = this.level().getNearestPlayer(getX(), getY(), getZ(), 48.0, EntitySelector.NO_CREATIVE_OR_SPECTATOR);
        if (target == null) {
            this.setDeltaMovement(Vec3.ZERO);
            return;
        }

        Vec3 to = target.position().add(0.0, 0.3, 0.0).subtract(this.position());
        double dist = to.length();
        Vec3 dir = dist > 1.0E-4 ? to.scale(1.0 / dist) : Vec3.ZERO;
        double speed = Math.min(0.24, dist);
        Vec3 side = new Vec3(-dir.z, 0.0, dir.x).scale(Math.sin(this.tickCount * 0.35) * 0.06);
        Vec3 vel = dir.scale(speed).add(side);
        if (this.horizontalCollision) vel = vel.add(0.0, 0.2, 0.0);
        this.setDeltaMovement(vel);

        if (this.tickCount % 40 == 0) {
            this.playSound(ModSounds.FLESH_SQUELCH.get(), 1.2F, 0.45F + this.random.nextFloat() * 0.2F);
        }
        if (grabCooldown <= 0 && this.getBoundingBox().inflate(0.6).intersects(target.getBoundingBox())) {
            grabbed = target.getUUID();
            grabTicks = 0;
            this.level().playSound(null, this.blockPosition(), ModSounds.TENTACLE_GRAB.get(), SoundSource.HOSTILE, 2.0F, 1.0F);
        }
    }

    private Player getGrabbed() {
        if (grabbed == null) return null;
        Player p = this.level().getPlayerByUUID(grabbed);
        if (p == null || !p.isAlive() || p.isSpectator()) {
            grabbed = null;
            return null;
        }
        return p;
    }

    private void hold(Player p) {
        grabTicks++;
        this.setDeltaMovement(0.0, 0.17, 0.0);
        Vec3 want = this.position().add(0.0, -1.2, 0.0);
        Vec3 diff = want.subtract(p.position());
        p.setDeltaMovement(diff.scale(0.4).add(0.0, 0.04, 0.0));
        p.hurtMarked = true;
        p.fallDistance = 0.0F;
        if (grabTicks == 12 || grabTicks == 30) {
            p.hurt(this.damageSources().mobAttack(this), 3.0F);
        }
        if (grabTicks >= HOLD_TICKS) release(true);
    }

    private void release(boolean retract) {
        grabbed = null;
        grabTicks = 0;
        grabCooldown = 70;
        if (retract) retractTicks = 0;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (scripted || this.tickCount < EXTEND_TICKS) return false;
        boolean result = super.hurt(source, amount);
        if (result && !this.level().isClientSide && grabbed != null && source.getEntity() instanceof Player) {
            release(false);   // hit it and it lets go
        }
        return result;
    }

    /** Called by the Sky Repellent. */
    public void repel() {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 0.5, getZ(), 30, 0.5, 0.8, 0.5, 0.1);
            sl.playSound(null, this.blockPosition(), ModSounds.CLEANSE.get(), SoundSource.HOSTILE, 1.0F, 0.7F);
        }
        this.discard();
    }

    private void vanish() {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SQUID_INK, getX(), getY() + 0.5, getZ(), 12, 0.4, 0.6, 0.4, 0.02);
        }
        this.discard();
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!this.level().isClientSide && this.random.nextFloat() < 0.35F) {
            this.spawnAtLocation(new ItemStack(ModItems.SKY_SHARD.get()));
        }
    }

    /* ------------------------------------------------------------------ misc */

    @Override
    public boolean isPickable() {
        return super.isPickable() && !scripted && this.tickCount >= EXTEND_TICKS;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeAffected(MobEffectInstance effect) {
        return false;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.FLESH_SQUELCH.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.FLESH_SQUELCH.get();
    }
}
