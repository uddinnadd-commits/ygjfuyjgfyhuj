package com.skyfall;

/** Phase thresholds, shared by server and client. */
public final class Phases {
    public static final int PHASE_2_SHARDS = 5;
    public static final int PHASE_3_SHARDS = 15;

    public static int of(int shardCount) {
        if (shardCount >= PHASE_3_SHARDS) return 3;
        if (shardCount >= PHASE_2_SHARDS) return 2;
        if (shardCount >= 1) return 1;
        return 0;
    }

    private Phases() {}
}
