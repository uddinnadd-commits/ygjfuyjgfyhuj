package com.skyfall.world;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.skyfall.Phases;
import com.skyfall.SkyfallMod;
import com.skyfall.story.SkyStory;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Admin / testing commands: /skyfall status | drop | tentacle | set <count> | phase <0-3> | reset */
@Mod.EventBusSubscriber(modid = SkyfallMod.MODID)
public final class SkyfallCommands {

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("skyfall")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("status").executes(c -> status(c.getSource())))
                .then(Commands.literal("drop").executes(c -> drop(c.getSource())))
                .then(Commands.literal("tentacle").executes(c -> tentacle(c.getSource())))
                .then(Commands.literal("sky").executes(c -> sky(c.getSource())))
                .then(Commands.literal("reset").executes(c -> reset(c.getSource())))
                .then(Commands.literal("set").then(Commands.argument("count", IntegerArgumentType.integer(0, 1000))
                        .executes(c -> set(c.getSource(), IntegerArgumentType.getInteger(c, "count")))))
                .then(Commands.literal("phase").then(Commands.argument("phase", IntegerArgumentType.integer(0, 3))
                        .executes(c -> {
                            int[] shards = {0, 1, Phases.PHASE_2_SHARDS, Phases.PHASE_3_SHARDS};
                            return set(c.getSource(), shards[IntegerArgumentType.getInteger(c, "phase")]);
                        }))));
    }

    private static int status(CommandSourceStack src) {
        SkyfallData d = SkyfallData.get(src.getServer().overworld());
        long untilNext = Math.max(0L, d.nextShardTick - src.getServer().overworld().getGameTime());
        src.sendSuccess(() -> Component.literal("Shards fallen: " + d.shardCount + " | phase " + Phases.of(d.shardCount)
                + " | next shard in ~" + (untilNext / 20L) + "s"), false);
        return d.shardCount;
    }

    private static int drop(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            src.sendFailure(Component.literal("The sky only breaks in the Overworld."));
            return 0;
        }
        SkyfallManager.dropShard(level, p);
        return 1;
    }

    private static int tentacle(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            src.sendFailure(Component.literal("Tentacles only reach down in the Overworld."));
            return 0;
        }
        if (SkyfallManager.phase() < 3) {
            src.sendFailure(Component.literal("Tentacles need phase 3. Try /skyfall phase 3"));
            return 0;
        }
        return SkyfallManager.spawnTentacle(level, p, SkyfallData.get(level)) ? 1 : 0;
    }

    private static int sky(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD) {
            src.sendFailure(Component.literal("SKY only exists in the Overworld."));
            return 0;
        }
        return SkyStory.arrive(level, SkyfallData.get(level), p, true) ? 1 : 0;
    }

    private static int reset(CommandSourceStack src) {
        SkyStory.resetStory(src.getServer().overworld());
        return set(src, 0);
    }

    private static int set(CommandSourceStack src, int count) {
        ServerLevel overworld = src.getServer().overworld();
        SkyfallManager.setCount(overworld, count);
        src.sendSuccess(() -> Component.literal("Shards fallen set to " + count + " (phase " + Phases.of(count) + ")"), true);
        return count;
    }

    private SkyfallCommands() {}
}
