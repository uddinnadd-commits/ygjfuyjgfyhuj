package com.skyfall.world;

import com.skyfall.Infection;
import com.skyfall.block.CorruptedBlock;
import com.skyfall.block.CorruptedBlockEntity;
import com.skyfall.entity.SkyTentacleEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** Everything the Sky Repellent does. */
public final class Cleansing {

    public static int cleanseBlocks(ServerLevel level, BlockPos center, int radius) {
        int count = 0;
        for (BlockPos p : BlockPos.betweenClosed(center.offset(-radius, -radius, -radius), center.offset(radius, radius, radius))) {
            if (p.distSqr(center) > radius * radius + 1) continue;
            BlockState s = level.getBlockState(p);
            if (!(s.getBlock() instanceof CorruptedBlock cb)) continue;
            BlockPos ip = p.immutable();
            BlockState original = null;
            BlockEntity be = level.getBlockEntity(ip);
            if (be instanceof CorruptedBlockEntity c && !c.getOriginal().isAir()) {
                original = c.getOriginal();
            }
            if (original == null) original = fallback(level, ip, cb.getKind());
            level.setBlock(ip, original, 3);
            level.sendParticles(ParticleTypes.END_ROD, ip.getX() + 0.5, ip.getY() + 1.0, ip.getZ() + 0.5, 2, 0.3, 0.3, 0.3, 0.02);
            count++;
        }
        return count;
    }

    private static BlockState fallback(ServerLevel level, BlockPos pos, CorruptedBlock.Kind kind) {
        return switch (kind) {
            case GROUND -> level.getBlockState(pos.above()).isAir()
                    ? Blocks.GRASS_BLOCK.defaultBlockState() : Blocks.DIRT.defaultBlockState();
            case LOG -> Blocks.OAK_LOG.defaultBlockState();
            case LEAVES -> Blocks.OAK_LEAVES.defaultBlockState().setValue(LeavesBlock.PERSISTENT, true);
            case FLESH -> Blocks.OAK_PLANKS.defaultBlockState();
        };
    }

    /** Removes the parasite from nearby animals and makes them immune. Returns how many were infected. */
    public static int cleanseMobs(ServerLevel level, BlockPos center, int radius) {
        int count = 0;
        for (Animal a : level.getEntitiesOfClass(Animal.class, new AABB(center).inflate(radius))) {
            if (!Infection.isInfected(a)) continue;
            Infection.setInfected(a, false);
            Infection.makeImmune(a);
            a.setTarget(null);
            a.getNavigation().stop();
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, a.getX(), a.getY() + a.getBbHeight() * 0.6, a.getZ(),
                    8, a.getBbWidth() * 0.5, 0.4, a.getBbWidth() * 0.5, 0.02);
            count++;
        }
        return count;
    }

    public static int repelTentacles(ServerLevel level, BlockPos center, int radius) {
        int count = 0;
        for (SkyTentacleEntity t : level.getEntitiesOfClass(SkyTentacleEntity.class, new AABB(center).inflate(radius))) {
            t.repel();
            count++;
        }
        return count;
    }

    private Cleansing() {}
}
