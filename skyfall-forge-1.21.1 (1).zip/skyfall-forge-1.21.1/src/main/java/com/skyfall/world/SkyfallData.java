package com.skyfall.world;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;

/** Per-world state: how many shards have fallen, when the next one falls, and the seed that places holes in the sky. */
public class SkyfallData extends SavedData {
    private static final String NAME = "skyfall_data";

    public int shardCount;
    public long nextShardTick = -1L;
    public long lastShardTime = -1L;
    public long seed;
    /** SKY has joined the world. */
    public boolean skyArrived;
    /** SKY has been taken; the story is over. */
    public boolean skyDone;

    public SkyfallData() {}

    public static SkyfallData get(ServerLevel overworld) {
        SkyfallData data = overworld.getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(SkyfallData::new, SkyfallData::load, DataFixTypes.LEVEL), NAME);
        if (data.seed == 0L) {
            data.seed = overworld.getSeed() ^ 0x5DEECE66DL ^ System.nanoTime();
            if (data.seed == 0L) data.seed = 1L;
            data.setDirty();
        }
        return data;
    }

    public static SkyfallData load(CompoundTag tag, HolderLookup.Provider registries) {
        SkyfallData d = new SkyfallData();
        d.shardCount = tag.getInt("ShardCount");
        d.nextShardTick = tag.contains("NextShardTick") ? tag.getLong("NextShardTick") : -1L;
        d.lastShardTime = tag.contains("LastShardTime") ? tag.getLong("LastShardTime") : -1L;
        d.seed = tag.getLong("Seed");
        d.skyArrived = tag.getBoolean("SkyArrived");
        d.skyDone = tag.getBoolean("SkyDone");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("ShardCount", shardCount);
        tag.putLong("NextShardTick", nextShardTick);
        tag.putLong("LastShardTime", lastShardTime);
        tag.putLong("Seed", seed);
        tag.putBoolean("SkyArrived", skyArrived);
        tag.putBoolean("SkyDone", skyDone);
        return tag;
    }
}
