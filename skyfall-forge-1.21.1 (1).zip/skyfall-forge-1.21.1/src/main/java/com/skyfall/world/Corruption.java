package com.skyfall.world;

import com.skyfall.block.CorruptedBlock;
import com.skyfall.block.CorruptedBlockEntity;
import com.skyfall.registry.ModBlocks;
import com.skyfall.registry.ModSounds;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** What can be corrupted, into what, and the actual corrupting. */
public final class Corruption {

    public static boolean isGround(BlockState s) {
        return s.is(BlockTags.DIRT) || s.is(BlockTags.SAND) || s.is(Blocks.GRAVEL) || s.is(Blocks.CLAY)
                || s.is(BlockTags.BASE_STONE_OVERWORLD);
    }

    /** Man-made full blocks: this is how the parasite gets into your house. */
    public static boolean isHouseBlock(BlockState s) {
        return s.is(BlockTags.PLANKS) || s.is(BlockTags.WOOL) || s.is(BlockTags.TERRACOTTA)
                || s.is(BlockTags.STONE_BRICKS) || s.is(BlockTags.IMPERMEABLE)
                || s.is(Blocks.COBBLESTONE) || s.is(Blocks.MOSSY_COBBLESTONE) || s.is(Blocks.BRICKS)
                || s.is(Blocks.SMOOTH_STONE);
    }

    public static Block replacementFor(ServerLevel level, BlockPos pos, BlockState s) {
        if (s.isAir() || s.hasBlockEntity() || s.getBlock() instanceof CorruptedBlock) return null;
        if (s.getDestroySpeed(level, pos) < 0.0F) return null;
        if (!s.getFluidState().isEmpty()) return null;
        if (s.is(BlockTags.LOGS)) return ModBlocks.FLESH_LOG.get();
        if (s.is(BlockTags.LEAVES)) return ModBlocks.FLESH_LEAVES.get();
        if (!Block.isShapeFullBlock(s.getShape(level, pos))) return null;
        if (isGround(s)) return ModBlocks.CORRUPTED_GROUND.get();
        if (isHouseBlock(s)) return ModBlocks.FLESH_BLOCK.get();
        return null;
    }

    public static boolean isExposed(ServerLevel level, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos n = pos.relative(d);
            if (!level.getBlockState(n).isSolidRender(level, n)) return true;
        }
        return false;
    }

    /** Corrupts one block. Plays the fleshy sound when {@code sound} is true. */
    public static boolean tryCorrupt(ServerLevel level, BlockPos pos, boolean sound) {
        if (!level.hasChunkAt(pos)) return false;
        BlockState s = level.getBlockState(pos);
        Block replacement = replacementFor(level, pos, s);
        if (replacement == null) return false;
        level.setBlock(pos, replacement.defaultBlockState(), 3);
        if (level.getBlockEntity(pos) instanceof CorruptedBlockEntity be) {
            be.setOriginal(s);
        }
        if (sound) {
            level.playSound(null, pos, ModSounds.FLESH_SQUELCH.get(), SoundSource.BLOCKS, 0.8F,
                    0.7F + level.random.nextFloat() * 0.4F);
            level.sendParticles(ParticleTypes.CRIMSON_SPORE, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                    4, 0.35, 0.2, 0.35, 0.01);
        }
        return true;
    }

    /** Corrupts exposed blocks in a sphere (up to {@code max} blocks), one sound for the whole blob. */
    public static int corruptBlob(ServerLevel level, BlockPos center, int radius, int max) {
        RandomSource r = level.random;
        List<BlockPos> candidates = new ArrayList<>();
        for (BlockPos p : BlockPos.betweenClosed(center.offset(-radius, -radius, -radius), center.offset(radius, radius, radius))) {
            if (p.distSqr(center) <= radius * radius + 1) candidates.add(p.immutable());
        }
        Collections.shuffle(candidates, new java.util.Random(r.nextLong()));
        int done = 0;
        for (BlockPos p : candidates) {
            if (done >= max) break;
            if (!level.hasChunkAt(p) || !isExposed(level, p)) continue;
            if (tryCorrupt(level, p, false)) done++;
        }
        if (done > 0) {
            level.playSound(null, center, ModSounds.FLESH_SQUELCH.get(), SoundSource.BLOCKS, 1.2F, 0.6F + r.nextFloat() * 0.3F);
        }
        return done;
    }

    private Corruption() {}
}
