package com.skyfall.world;

import com.skyfall.Phases;
import com.skyfall.SkyMath;
import com.skyfall.SkyfallConfig;
import com.skyfall.SkyfallMod;
import com.skyfall.entity.SkyShardEntity;
import com.skyfall.entity.SkyTentacleEntity;
import com.skyfall.network.Net;
import com.skyfall.network.SkySyncPacket;
import com.skyfall.registry.ModEntities;
import com.skyfall.registry.ModSounds;
import com.skyfall.story.SkyStory;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server-side brain of the mod: schedules shards, tracks the phase, types the hotbar text, seeds corruption and tentacles. */
@Mod.EventBusSubscriber(modid = SkyfallMod.MODID)
public final class SkyfallManager {
    public static final String MESSAGE = "The sky falls again.";

    private static volatile int cachedCount = 0;
    private static final Map<UUID, Typewriter> TYPEWRITERS = new HashMap<>();

    public static int shardCount() {
        return cachedCount;
    }

    public static int phase() {
        return Phases.of(cachedCount);
    }

    /* ------------------------------------------------------------------ lifecycle / sync */

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent e) {
        ServerLevel overworld = e.getServer().overworld();
        if (overworld != null) cachedCount = SkyfallData.get(overworld).shardCount;
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        cachedCount = 0;
        TYPEWRITERS.clear();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) syncTo(sp, false);
    }

    @SubscribeEvent
    public static void onChangedDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) syncTo(sp, false);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) syncTo(sp, false);
    }

    public static void syncTo(ServerPlayer player, boolean animate) {
        ServerLevel overworld = player.server.overworld();
        SkyfallData d = SkyfallData.get(overworld);
        Net.sendTo(player, new SkySyncPacket(d.shardCount, d.seed, animate));
    }

    public static void syncAll(ServerLevel overworld, boolean animate) {
        SkyfallData d = SkyfallData.get(overworld);
        SkySyncPacket packet = new SkySyncPacket(d.shardCount, d.seed, animate);
        for (ServerPlayer p : overworld.players()) Net.sendTo(p, packet);
    }

    public static void setCount(ServerLevel overworld, int count) {
        SkyfallData d = SkyfallData.get(overworld);
        d.shardCount = Math.max(0, count);
        d.setDirty();
        cachedCount = d.shardCount;
        syncAll(overworld, false);
    }

    /* ------------------------------------------------------------------ main tick */

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent.Post e) {
        if (!(e.level instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) return;

        tickTypewriters(level.getServer());

        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;

        SkyfallData data = SkyfallData.get(level);
        long time = level.getGameTime();

        if (data.nextShardTick < 0L) {
            data.nextShardTick = time + randomInterval(level.random);
            data.setDirty();
        }
        if (time >= data.nextShardTick && !SkyStory.isCutsceneActive()) {
            ServerPlayer target = players.get(level.random.nextInt(players.size()));
            dropShard(level, target);
        }

        if (Phases.of(data.shardCount) >= 3) {
            if (time % 80L == 0L && SkyfallConfig.ENABLE_CORRUPTION.get()) seedCorruption(level, players);
            if (time % 100L == 0L && SkyfallConfig.ENABLE_TENTACLES.get()
                    && level.getDifficulty() != Difficulty.PEACEFUL) spawnTentacles(level, players, data);
        }
    }

    private static long randomInterval(RandomSource r) {
        int min = Math.min(SkyfallConfig.SHARD_MIN_TICKS.get(), SkyfallConfig.SHARD_MAX_TICKS.get());
        int max = Math.max(SkyfallConfig.SHARD_MIN_TICKS.get(), SkyfallConfig.SHARD_MAX_TICKS.get());
        return min + (max > min ? r.nextInt(max - min + 1) : 0);
    }

    /* ------------------------------------------------------------------ shards */

    /** A piece of the sky breaks off and starts to fall near {@code target}. */
    public static void dropShard(ServerLevel level, ServerPlayer target) {
        SkyfallData data = SkyfallData.get(level);
        int index = data.shardCount;
        data.shardCount++;
        data.lastShardTime = level.getGameTime();
        data.nextShardTick = level.getGameTime() + randomInterval(level.random);
        data.setDirty();
        cachedCount = data.shardCount;

        // The shard peels off from the hole that just opened, then falls straight down.
        Vec3 dir = SkyMath.holeDirection(data.seed, index);
        double hl = Math.sqrt(dir.x * dir.x + dir.z * dir.z);
        double nx = hl > 1.0E-4 ? dir.x / hl : 1.0;
        double nz = hl > 1.0E-4 ? dir.z / hl : 0.0;
        double reach = Math.min(hl * 120.0, 56.0);
        RandomSource r = level.random;
        double x = target.getX() + nx * reach + (r.nextDouble() - 0.5) * 6.0;
        double z = target.getZ() + nz * reach + (r.nextDouble() - 0.5) * 6.0;
        double groundY = target.getY();
        BlockPos probe = BlockPos.containing(x, target.getY(), z);
        if (level.hasChunkAt(probe)) {
            groundY = Math.max(groundY, level.getHeight(Heightmap.Types.MOTION_BLOCKING, probe.getX(), probe.getZ()));
        }

        SkyShardEntity shard = new SkyShardEntity(ModEntities.SKY_SHARD.get(), level);
        shard.randomize(r);
        shard.setPos(x, groundY + 70.0 + r.nextInt(35), z);
        shard.setDeltaMovement(0.0, -0.4, 0.0);
        level.addFreshEntity(shard);

        for (ServerPlayer p : level.players()) {
            p.playNotifySound(ModSounds.SKY_CRACK.get(), SoundSource.AMBIENT, 1.0F, 0.9F + r.nextFloat() * 0.2F);
            startTypewriter(p, MESSAGE);
        }
        syncAll(level, true);
    }

    /* ------------------------------------------------------------------ typewriter hotbar text */

    private static final class Typewriter {
        final String text;
        int tick;

        Typewriter(String text) {
            this.text = text;
        }
    }

    public static void startTypewriter(ServerPlayer player, String text) {
        TYPEWRITERS.put(player.getUUID(), new Typewriter(text));
    }

    private static void tickTypewriters(MinecraftServer server) {
        if (TYPEWRITERS.isEmpty()) return;
        Iterator<Map.Entry<UUID, Typewriter>> it = TYPEWRITERS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Typewriter> entry = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(entry.getKey());
            if (p == null) {
                it.remove();
                continue;
            }
            Typewriter t = entry.getValue();
            t.tick++;
            int local = t.tick - 20;           // one second of silence after the crack, then the typing starts
            if (local < 0 || local % 2 != 0) continue;
            int shown = local / 2 + 1;
            if (shown > t.text.length()) {
                it.remove();
                continue;
            }
            String sub = t.text.substring(0, shown);
            if (shown < t.text.length()) sub += "_";
            p.displayClientMessage(Component.literal(sub).withStyle(ChatFormatting.DARK_RED), true);
            if (t.text.charAt(shown - 1) != ' ') {
                p.playNotifySound(ModSounds.TYPE_KEY.get(), SoundSource.MASTER, 0.6F, 0.9F + p.getRandom().nextFloat() * 0.25F);
            }
        }
    }

    /* ------------------------------------------------------------------ phase 3: corruption + tentacles */

    private static void seedCorruption(ServerLevel level, List<ServerPlayer> players) {
        RandomSource r = level.random;
        for (ServerPlayer p : players) {
            if (p.isSpectator()) continue;
            // 1) ground patches around the player
            for (int i = 0; i < 2; i++) {
                double a = r.nextDouble() * Math.PI * 2.0;
                double d = 8.0 + r.nextDouble() * 36.0;
                int x = Mth.floor(p.getX() + Math.cos(a) * d);
                int z = Mth.floor(p.getZ() + Math.sin(a) * d);
                if (!level.hasChunkAt(new BlockPos(x, p.getBlockY(), z))) continue;
                int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
                Corruption.corruptBlob(level, new BlockPos(x, y, z), 1 + r.nextInt(3), 18);
            }
            // 2) the parasite also goes for buildings
            for (int i = 0; i < 12; i++) {
                BlockPos pos = p.blockPosition().offset(r.nextInt(41) - 20, r.nextInt(21) - 8, r.nextInt(41) - 20);
                if (!level.hasChunkAt(pos)) continue;
                BlockState s = level.getBlockState(pos);
                if (Corruption.isHouseBlock(s) && Corruption.isExposed(level, pos)) {
                    Corruption.corruptBlob(level, pos, 2, 10);
                    break;
                }
            }
        }
    }

    private static void spawnTentacles(ServerLevel level, List<ServerPlayer> players, SkyfallData data) {
        RandomSource r = level.random;
        for (ServerPlayer p : players) {
            if (p.isSpectator() || p.isCreative()) continue;
            if (!level.canSeeSky(p.blockPosition())) continue;
            int existing = level.getEntitiesOfClass(SkyTentacleEntity.class, p.getBoundingBox().inflate(64.0)).size();
            if (existing >= 2 || r.nextFloat() > 0.45F) continue;
            spawnTentacle(level, p, data);
        }
    }

    public static boolean spawnTentacle(ServerLevel level, ServerPlayer p, SkyfallData data) {
        RandomSource r = level.random;
        double a = r.nextDouble() * Math.PI * 2.0;
        double d = 14.0 + r.nextDouble() * 10.0;
        int x = Mth.floor(p.getX() + Math.cos(a) * d);
        int z = Mth.floor(p.getZ() + Math.sin(a) * d);
        if (!level.hasChunkAt(new BlockPos(x, p.getBlockY(), z))) return false;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);

        SkyTentacleEntity t = new SkyTentacleEntity(ModEntities.TENTACLE.get(), level);
        t.setPos(x + 0.5, y + 0.2, z + 0.5);
        t.setSkyDirection(pickSkyDirection(data, r));
        level.addFreshEntity(t);
        level.playSound(null, t.blockPosition(), ModSounds.FLESH_SQUELCH.get(), SoundSource.HOSTILE, 1.6F, 0.5F);
        return true;
    }

    /** Tentacles hang down from one of the actual holes in the sky. */
    private static Vec3 pickSkyDirection(SkyfallData data, RandomSource r) {
        int n = Math.max(1, data.shardCount);
        Vec3 v = SkyMath.holeDirection(data.seed, r.nextInt(n));
        return new Vec3(v.x, Math.max(v.y, 0.65), v.z).normalize();
    }

    private SkyfallManager() {}
}
