package com.skyfall.story;

import com.skyfall.Phases;
import com.skyfall.SkyfallMod;
import com.skyfall.entity.SkyNpcEntity;
import com.skyfall.entity.SkyTentacleEntity;
import com.skyfall.network.Net;
import com.skyfall.network.SkyCutscenePacket;
import com.skyfall.registry.ModEntities;
import com.skyfall.registry.ModItems;
import com.skyfall.registry.ModSounds;
import com.skyfall.world.SkyfallData;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * SKY's story.
 *
 *  - Once the 10th shard has fallen (halfway between phase 2 and phase 3) SKY "joins the game": a vanilla join
 *    message, a few chat lines, and she appears near a player.
 *  - When someone walks up to her a cutscene starts. She talks for about 22 seconds, walks up and tries to put a
 *    hand on your shoulder, and is cut off mid-sentence when a tentacle comes down out of the sky, seizes her and
 *    drags her up into the void. A few seconds later the next shard falls.
 *
 * The server owns the timeline (everything below is in ticks since the cutscene began); the client only shows it.
 */
@Mod.EventBusSubscriber(modid = SkyfallMod.MODID)
public final class SkyStory {
    public static final int ARRIVAL_SHARDS = 10;

    /** When each dialogue line starts. Her last line (6) is cut off at STRIKE_TICK. */
    private static final int[] LINE_TICKS = {10, 60, 135, 210, 280, 345, 418};
    private static final int REACH_TICK = 270;      // she walks up to you and reaches out
    private static final int TOUCH_TICK = 330;      // her hand lands on your shoulder
    private static final int TENTACLE_TICK = 395;   // the tentacle starts to lower itself behind her (takes 50 ticks)
    private static final int STRIKE_TICK = 450;     // cut off. ~22 s of talking
    private static final int GRAB_TICK = 456;
    private static final int MAX_DRAG_TICKS = 110;
    private static final int FADE_TO_STOP = 50;

    /** Waiting-for-you chat lines, in ticks after she arrives. */
    private static final int[] CHAT_DELAYS = {60, 220, 1300, 3600};

    private static final class Cutscene {
        UUID sky;
        UUID focus;
        UUID tentacle;
        final List<UUID> players = new ArrayList<>();
        int t;
        int vanishedAt = -1;
        double startY;
        Vec3 dragDir = new Vec3(0, 1, 0);
    }

    private static Cutscene active;
    private static long arrivalTime = -1L;
    private static int chatIndex = CHAT_DELAYS.length;   // no chat unless she just arrived

    public static boolean isCutsceneActive() {
        return active != null;
    }

    public static boolean isActiveFor(SkyNpcEntity npc) {
        return active != null && active.sky.equals(npc.getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent e) {
        active = null;
        arrivalTime = -1L;
        chatIndex = CHAT_DELAYS.length;
    }

    /* ------------------------------------------------------------------ arrival */

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent.Post e) {
        if (!(e.level instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) return;
        SkyfallData data = SkyfallData.get(level);
        if (active != null) {
            tickCutscene(level, data);
            return;
        }
        long time = level.getGameTime();
        if (!data.skyArrived && data.shardCount >= ARRIVAL_SHARDS && data.shardCount < Phases.PHASE_3_SHARDS && time % 40L == 0L) {
            List<ServerPlayer> players = level.players().stream().filter(p -> !p.isSpectator()).toList();
            if (!players.isEmpty()) arrive(level, data, players.get(level.random.nextInt(players.size())), false);
        }
        tickWaitingChat(level, data);
    }

    /** SKY joins the game. {@code forced} is for /skyfall sky (spawns her close by, any time, any number of times). */
    public static boolean arrive(ServerLevel level, SkyfallData data, ServerPlayer near, boolean forced) {
        if (forced) {
            abort(level);
            for (SkyNpcEntity n : allSky(level)) n.discard();
        } else if (data.skyArrived) {
            return false;
        }

        RandomSource r = level.random;
        double x = near.getX() + 8.0, z = near.getZ(), y = near.getY();
        double minD = forced ? 8.0 : 18.0, rangeD = forced ? 4.0 : 8.0;
        for (int i = 0; i < 10; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            double d = minD + r.nextDouble() * rangeD;
            int cx = Mth.floor(near.getX() + Math.cos(a) * d);
            int cz = Mth.floor(near.getZ() + Math.sin(a) * d);
            if (!level.hasChunkAt(new BlockPos(cx, near.getBlockY(), cz))) continue;
            int cy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, cx, cz);
            if (!level.getBlockState(new BlockPos(cx, cy - 1, cz)).getFluidState().isEmpty()) continue;
            x = cx + 0.5;
            z = cz + 0.5;
            y = cy;
            break;
        }

        SkyNpcEntity npc = new SkyNpcEntity(ModEntities.SKY_NPC.get(), level);
        npc.moveTo(x, y, z, r.nextFloat() * 360.0F, 0.0F);
        level.addFreshEntity(npc);

        data.skyArrived = true;
        data.skyDone = false;
        data.setDirty();
        arrivalTime = level.getGameTime();
        chatIndex = 0;

        level.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("multiplayer.player.joined", Component.literal("SKY")).withStyle(ChatFormatting.YELLOW), false);
        return true;
    }

    private static void tickWaitingChat(ServerLevel level, SkyfallData data) {
        if (!data.skyArrived || data.skyDone || chatIndex >= CHAT_DELAYS.length) return;
        if (level.getGameTime() - arrivalTime < CHAT_DELAYS[chatIndex]) return;
        int i = chatIndex++;
        SkyNpcEntity npc = allSky(level).stream().findFirst().orElse(null);
        if (npc == null) return;
        String text = switch (i) {
            case 0 -> "is anyone there.";
            case 1 -> "i can see you. come here. quickly.";
            case 2 -> "i'm at " + npc.getBlockX() + " " + npc.getBlockY() + " " + npc.getBlockZ() + ". please. i don't have long.";
            default -> "it's getting louder up there. come.";
        };
        level.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("chat.type.text", Component.literal("SKY"), Component.literal(text)), false);
    }

    private static List<SkyNpcEntity> allSky(ServerLevel level) {
        List<SkyNpcEntity> list = new ArrayList<>();
        for (Entity e : level.getAllEntities()) {
            if (e instanceof SkyNpcEntity n) list.add(n);
        }
        return list;
    }

    /** /skyfall reset: SKY never came. */
    public static void resetStory(ServerLevel level) {
        abort(level);
        for (SkyNpcEntity n : allSky(level)) n.discard();
        SkyfallData data = SkyfallData.get(level);
        data.skyArrived = false;
        data.skyDone = false;
        data.setDirty();
        chatIndex = CHAT_DELAYS.length;
    }

    /* ------------------------------------------------------------------ cutscene */

    public static void begin(ServerLevel level, SkyNpcEntity npc, ServerPlayer trigger) {
        if (active != null) return;
        if (SkyfallData.get(level).skyDone) return;

        Cutscene c = new Cutscene();
        c.sky = npc.getUUID();
        c.focus = trigger.getUUID();
        for (ServerPlayer p : level.players()) {
            if (!p.isSpectator() && p.distanceToSqr(npc) < 24.0 * 24.0) c.players.add(p.getUUID());
        }
        if (!c.players.contains(c.focus)) c.players.add(c.focus);
        active = c;

        npc.setState(SkyNpcEntity.TALK);
        npc.getNavigation().stop();
        for (ServerPlayer p : players(level, c)) {
            Net.sendTo(p, new SkyCutscenePacket(SkyCutscenePacket.START, npc.getId(), 0));
            giveShield(p);
        }
    }

    private static List<ServerPlayer> players(ServerLevel level, Cutscene c) {
        List<ServerPlayer> list = new ArrayList<>();
        for (UUID id : c.players) {
            ServerPlayer p = level.getServer().getPlayerList().getPlayer(id);
            if (p != null && p.level() == level) list.add(p);
        }
        return list;
    }

    /** Resistance V, hidden: nothing can hurt you while the cutscene holds your attention. */
    private static void giveShield(ServerPlayer p) {
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 900, 4, false, false, false));
    }

    private static void removeShield(ServerPlayer p) {
        MobEffectInstance cur = p.getEffect(MobEffects.DAMAGE_RESISTANCE);
        if (cur != null && cur.getAmplifier() == 4 && !cur.isVisible()) p.removeEffect(MobEffects.DAMAGE_RESISTANCE);
    }

    private static void send(List<ServerPlayer> ps, int action, int entityId, int arg) {
        SkyCutscenePacket packet = new SkyCutscenePacket(action, entityId, arg);
        for (ServerPlayer p : ps) Net.sendTo(p, packet);
    }

    private static void face(SkyNpcEntity npc, Entity target) {
        double dx = target.getX() - npc.getX();
        double dz = target.getZ() - npc.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * 57.29577951308232D) - 90.0F;
        npc.setYRot(yaw);
        npc.yBodyRot = yaw;
        npc.yHeadRot = yaw;
    }

    private static void tickCutscene(ServerLevel level, SkyfallData data) {
        Cutscene c = active;
        c.t++;
        int t = c.t;
        List<ServerPlayer> ps = players(level, c);

        // after she is gone we only wait for the fade
        if (c.vanishedAt >= 0) {
            if (t >= c.vanishedAt + FADE_TO_STOP) finish(level, data, ps);
            return;
        }

        Entity skyEntity = level.getEntity(c.sky);
        if (!(skyEntity instanceof SkyNpcEntity npc) || ps.isEmpty()) {
            abort(level);
            return;
        }
        ServerPlayer focus = ps.get(0);
        for (ServerPlayer p : ps) {
            if (p.getUUID().equals(c.focus)) focus = p;
        }
        if (t % 100 == 0) {
            for (ServerPlayer p : ps) giveShield(p);
        }

        // unit vector pointing from the player to SKY (horizontal): "behind her" is further along it
        Vec3 away = new Vec3(npc.getX() - focus.getX(), 0.0, npc.getZ() - focus.getZ());
        away = away.lengthSqr() > 1.0E-4 ? away.normalize() : new Vec3(1.0, 0.0, 0.0);

        for (int i = 0; i < LINE_TICKS.length; i++) {
            if (t == LINE_TICKS[i]) send(ps, SkyCutscenePacket.LINE, npc.getId(), i);
        }

        if (t < GRAB_TICK) {
            npc.getLookControl().setLookAt(focus, 60.0F, 60.0F);
            if (t >= REACH_TICK) {
                if (t == REACH_TICK) npc.setState(SkyNpcEntity.REACH);
                Vec3 stand = focus.position().add(away.scale(0.9));
                double dx = stand.x - npc.getX(), dz = stand.z - npc.getZ();
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > 0.35 && (npc.getNavigation().isDone() || t % 10 == 0)) {
                    npc.getNavigation().moveTo(stand.x, stand.y, stand.z, 0.95);
                }
                if (dist < 1.5) {                                   // settle in exactly one arm's length away
                    npc.setDeltaMovement(npc.getDeltaMovement().add(dx * 0.1, 0.0, dz * 0.1));
                    face(npc, focus);
                }
                if (t == TOUCH_TICK) send(ps, SkyCutscenePacket.TOUCH, npc.getId(), 0);
            } else if (t >= 100 && t % 20 == 0 && npc.distanceToSqr(focus) > 3.2 * 3.2) {
                Vec3 nearPos = focus.position().add(away.scale(2.6));   // creep closer while she talks
                npc.getNavigation().moveTo(nearPos.x, nearPos.y, nearPos.z, 0.7);
            }
        }

        if (t == TENTACLE_TICK) spawnCutsceneTentacle(level, c, npc, away);

        SkyTentacleEntity tent = c.tentacle != null && level.getEntity(c.tentacle) instanceof SkyTentacleEntity te ? te : null;
        if (t >= TENTACLE_TICK && tent == null) {
            abort(level);
            return;
        }

        if (t == STRIKE_TICK) {
            send(ps, SkyCutscenePacket.CUTOFF, npc.getId(), 0);
            level.playSound(null, npc.blockPosition(), ModSounds.TENTACLE_GRAB.get(), SoundSource.HOSTILE, 3.0F, 0.9F);
            level.playSound(null, npc.blockPosition(), ModSounds.SKY_SCREAM.get(), SoundSource.VOICE, 4.0F, 1.0F);
        }
        if (tent != null && t >= STRIKE_TICK && t < GRAB_TICK) {          // the tip lunges at her
            Vec3 to = npc.position().add(0.0, 0.9, 0.0).subtract(tent.position());
            double d = to.length();
            tent.setDeltaMovement(d > 1.0E-4 ? to.scale(Math.min(d, 1.2) / d) : Vec3.ZERO);
        }
        if (t == GRAB_TICK) {
            npc.setState(SkyNpcEntity.GRABBED);
            npc.setNoGravity(true);
            npc.noPhysics = true;
            npc.getNavigation().stop();
            npc.spawnAtLocation(new ItemStack(ModItems.SKY_SHARD.get(), 2));   // she drops something as she is taken
        }
        if (tent != null && t >= GRAB_TICK) {                              // up into the sky
            int dt = t - GRAB_TICK;
            double speed = Math.min(2.2, 0.12 + 0.035 * dt);
            tent.setDeltaMovement(c.dragDir.scale(speed));
            npc.setPos(tent.getX(), tent.getY() - 0.9, tent.getZ());
            npc.setDeltaMovement(Vec3.ZERO);
            npc.fallDistance = 0.0F;
            if (dt > MAX_DRAG_TICKS || tent.getY() > c.startY + 90.0) {
                c.vanishedAt = t;
                send(ps, SkyCutscenePacket.FADE, npc.getId(), 0);
                npc.discard();
                tent.discard();
            }
        }
    }

    private static void spawnCutsceneTentacle(ServerLevel level, Cutscene c, SkyNpcEntity npc, Vec3 away) {
        Vec3 behind = npc.position().add(away.scale(3.5));
        double ty = npc.getY();
        BlockPos probe = BlockPos.containing(behind.x, ty, behind.z);
        if (level.hasChunkAt(probe)) {
            int gy = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, probe.getX(), probe.getZ());
            if (Math.abs(gy - ty) <= 3) ty = gy;
        }
        c.dragDir = new Vec3(away.x * 0.35, 1.0, away.z * 0.35).normalize();
        c.startY = npc.getY();

        SkyTentacleEntity tent = new SkyTentacleEntity(ModEntities.TENTACLE.get(), level);
        tent.setScripted(true);
        tent.setSkyDirection(c.dragDir);
        tent.setPos(behind.x, ty + 0.2, behind.z);
        level.addFreshEntity(tent);
        c.tentacle = tent.getUUID();
        level.playSound(null, tent.blockPosition(), ModSounds.FLESH_SQUELCH.get(), SoundSource.HOSTILE, 1.4F, 0.5F);
    }

    private static void finish(ServerLevel level, SkyfallData data, List<ServerPlayer> ps) {
        for (ServerPlayer p : ps) {
            Net.sendTo(p, new SkyCutscenePacket(SkyCutscenePacket.STOP, 0, 0));
            removeShield(p);
        }
        data.skyDone = true;
        data.nextShardTick = level.getGameTime() + 100L;      // the sky falls again, soon
        data.setDirty();
        active = null;
    }

    /** Something went wrong (player left, SKY or the tentacle vanished): end it cleanly, let her wait again. */
    private static void abort(ServerLevel level) {
        Cutscene c = active;
        if (c == null) return;
        active = null;
        for (ServerPlayer p : players(level, c)) {
            Net.sendTo(p, new SkyCutscenePacket(SkyCutscenePacket.STOP, 0, 0));
            removeShield(p);
        }
        if (c.tentacle != null && level.getEntity(c.tentacle) != null) level.getEntity(c.tentacle).discard();
        if (level.getEntity(c.sky) instanceof SkyNpcEntity npc) {
            npc.setState(SkyNpcEntity.IDLE);
            npc.setNoGravity(false);
            npc.noPhysics = false;
        }
    }

    private SkyStory() {}
}
