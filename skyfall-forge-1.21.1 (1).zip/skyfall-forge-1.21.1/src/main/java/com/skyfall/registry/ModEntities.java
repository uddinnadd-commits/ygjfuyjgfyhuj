package com.skyfall.registry;

import com.skyfall.SkyfallMod;
import com.skyfall.entity.SkyNpcEntity;
import com.skyfall.entity.SkyShardEntity;
import com.skyfall.entity.SkyTentacleEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SkyfallMod.MODID);

    public static final RegistryObject<EntityType<SkyShardEntity>> SKY_SHARD = ENTITIES.register("sky_shard",
            () -> EntityType.Builder.<SkyShardEntity>of(SkyShardEntity::new, MobCategory.MISC)
                    .sized(1.2F, 1.2F).clientTrackingRange(16).updateInterval(2).fireImmune().noSave()
                    .build(SkyfallMod.MODID + ":sky_shard"));

    public static final RegistryObject<EntityType<SkyTentacleEntity>> TENTACLE = ENTITIES.register("sky_tentacle",
            () -> EntityType.Builder.<SkyTentacleEntity>of(SkyTentacleEntity::new, MobCategory.MONSTER)
                    .sized(1.0F, 1.0F).clientTrackingRange(16).updateInterval(1).fireImmune().noSave()
                    .build(SkyfallMod.MODID + ":sky_tentacle"));

    /** SKY: the guide who falls from the sky. */
    public static final RegistryObject<EntityType<SkyNpcEntity>> SKY_NPC = ENTITIES.register("sky_npc",
            () -> EntityType.Builder.<SkyNpcEntity>of(SkyNpcEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(10).updateInterval(2)
                    .build(SkyfallMod.MODID + ":sky_npc"));

    private ModEntities() {}
}
