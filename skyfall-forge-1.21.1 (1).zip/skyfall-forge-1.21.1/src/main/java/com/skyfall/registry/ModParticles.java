package com.skyfall.registry;

import com.skyfall.SkyfallMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, SkyfallMod.MODID);

    public static final RegistryObject<SimpleParticleType> PARASITE = PARTICLES.register("parasite", () -> new SimpleParticleType(false));

    private ModParticles() {}
}
