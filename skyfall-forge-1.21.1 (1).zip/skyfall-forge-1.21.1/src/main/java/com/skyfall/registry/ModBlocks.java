package com.skyfall.registry;

import com.skyfall.SkyfallMod;
import com.skyfall.block.CorruptedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SkyfallMod.MODID);

    public static final RegistryObject<Block> CORRUPTED_GROUND = BLOCKS.register("corrupted_ground",
            () -> new CorruptedBlock(props(MapColor.COLOR_RED, 0.9F), CorruptedBlock.Kind.GROUND));
    public static final RegistryObject<Block> FLESH_LOG = BLOCKS.register("flesh_log",
            () -> new CorruptedBlock(props(MapColor.CRIMSON_STEM, 1.0F), CorruptedBlock.Kind.LOG));
    public static final RegistryObject<Block> FLESH_LEAVES = BLOCKS.register("flesh_leaves",
            () -> new CorruptedBlock(props(MapColor.COLOR_PINK, 0.5F), CorruptedBlock.Kind.LEAVES));
    public static final RegistryObject<Block> FLESH_BLOCK = BLOCKS.register("flesh_block",
            () -> new CorruptedBlock(props(MapColor.TERRACOTTA_PINK, 1.0F), CorruptedBlock.Kind.FLESH));

    private static BlockBehaviour.Properties props(MapColor color, float strength) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(strength)
                .sound(ModSounds.FLESH).randomTicks();
    }

    private ModBlocks() {}
}
