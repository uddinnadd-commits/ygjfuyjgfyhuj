package com.skyfall.registry;

import com.skyfall.SkyfallMod;
import com.skyfall.item.SkyRepellentItem;
import com.skyfall.item.SkyShardItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SkyfallMod.MODID);

    public static final RegistryObject<Item> SKY_SHARD = ITEMS.register("sky_shard",
            () -> new SkyShardItem(new Item.Properties().rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> SKY_REPELLENT = ITEMS.register("sky_repellent",
            () -> new SkyRepellentItem(new Item.Properties().durability(10).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> CORRUPTED_GROUND = blockItem("corrupted_ground", ModBlocks.CORRUPTED_GROUND);
    public static final RegistryObject<Item> FLESH_LOG = blockItem("flesh_log", ModBlocks.FLESH_LOG);
    public static final RegistryObject<Item> FLESH_LEAVES = blockItem("flesh_leaves", ModBlocks.FLESH_LEAVES);
    public static final RegistryObject<Item> FLESH_BLOCK = blockItem("flesh_block", ModBlocks.FLESH_BLOCK);

    private static RegistryObject<Item> blockItem(String name, RegistryObject<Block> block) {
        return ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    private ModItems() {}
}
