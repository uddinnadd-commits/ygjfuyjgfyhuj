package com.skyfall.registry;

import com.skyfall.SkyfallMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SkyfallMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.skyfall"))
            .icon(() -> new ItemStack(ModItems.SKY_SHARD.get()))
            .displayItems((params, out) -> {
                out.accept(ModItems.SKY_SHARD.get());
                out.accept(ModItems.SKY_REPELLENT.get());
                out.accept(ModItems.CORRUPTED_GROUND.get());
                out.accept(ModItems.FLESH_LOG.get());
                out.accept(ModItems.FLESH_LEAVES.get());
                out.accept(ModItems.FLESH_BLOCK.get());
            }).build());

    private ModTabs() {}
}
