package com.skyfall.registry;

import com.skyfall.SkyfallMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.common.util.ForgeSoundType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SkyfallMod.MODID);

    public static final RegistryObject<SoundEvent> TYPE_KEY = reg("type_key");
    public static final RegistryObject<SoundEvent> FLESH_SQUELCH = reg("flesh_squelch");
    public static final RegistryObject<SoundEvent> SKY_CRACK = reg("sky_crack");
    public static final RegistryObject<SoundEvent> SHARD_IMPACT = reg("shard_impact");
    public static final RegistryObject<SoundEvent> BITE = reg("bite");
    public static final RegistryObject<SoundEvent> CLEANSE = reg("cleanse");
    public static final RegistryObject<SoundEvent> TENTACLE_GRAB = reg("tentacle_grab");
    public static final RegistryObject<SoundEvent> SKY_VOICE = reg("sky_voice");
    public static final RegistryObject<SoundEvent> SKY_SCREAM = reg("sky_scream");

    /** Squishy flesh block sounds (break / step / place / hit / fall all squelch). */
    public static final ForgeSoundType FLESH = new ForgeSoundType(0.9F, 0.7F,
            FLESH_SQUELCH, FLESH_SQUELCH, FLESH_SQUELCH, FLESH_SQUELCH, FLESH_SQUELCH);

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(SkyfallMod.MODID, name)));
    }

    private ModSounds() {}
}
