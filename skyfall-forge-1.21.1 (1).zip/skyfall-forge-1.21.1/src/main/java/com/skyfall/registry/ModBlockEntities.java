package com.skyfall.registry;

import com.skyfall.SkyfallMod;
import com.skyfall.block.CorruptedBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, SkyfallMod.MODID);

    public static final RegistryObject<BlockEntityType<CorruptedBlockEntity>> CORRUPTED = BLOCK_ENTITIES.register("corrupted",
            () -> BlockEntityType.Builder.of(CorruptedBlockEntity::new,
                    ModBlocks.CORRUPTED_GROUND.get(), ModBlocks.FLESH_LOG.get(),
                    ModBlocks.FLESH_LEAVES.get(), ModBlocks.FLESH_BLOCK.get()).build(null));

    private ModBlockEntities() {}
}
