package com.skyfall;

import java.util.Random;
import net.minecraft.world.phys.Vec3;

/** Deterministic helpers shared by client (rendering) and server (shard / tentacle origin). */
public final class SkyMath {
    private static long mix(long z) {
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    /** Unit vector pointing at the centre of hole number {@code index} in the sky. */
    public static Vec3 holeDirection(long seed, int index) {
        Random r = new Random(mix(seed + index * 0x9E3779B97F4A7C15L));
        r.nextDouble();
        double az = r.nextDouble() * Math.PI * 2.0;
        double sinMin = Math.sin(Math.toRadians(22.0));
        double sinMax = Math.sin(Math.toRadians(86.0));
        double sinEl = sinMin + r.nextDouble() * (sinMax - sinMin);
        double cosEl = Math.sqrt(1.0 - sinEl * sinEl);
        return new Vec3(Math.cos(az) * cosEl, sinEl, Math.sin(az) * cosEl);
    }

    private SkyMath() {}
}
