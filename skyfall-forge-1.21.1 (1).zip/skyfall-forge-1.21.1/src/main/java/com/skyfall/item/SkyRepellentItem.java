package com.skyfall.item;

import com.skyfall.registry.ModSounds;
import com.skyfall.world.Cleansing;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Right-click: cleanses corrupted blocks (restoring what they were), cures parasite-infected animals, banishes
 * tentacles and cures your Wither. Only 10 durability.
 */
public class SkyRepellentItem extends Item {
    private static final int RADIUS = 5;

    public SkyRepellentItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel sl)) {
            return InteractionResultHolder.sidedSuccess(stack, true);
        }

        BlockHitResult hit = getPlayerPOVHitResult(level, player, ClipContext.Fluid.NONE);
        BlockPos center = hit.getType() == HitResult.Type.BLOCK ? hit.getBlockPos() : player.blockPosition();

        int blocks = Cleansing.cleanseBlocks(sl, center, RADIUS);
        int animals = Cleansing.cleanseMobs(sl, center, RADIUS + 1);
        int tentacles = Cleansing.repelTentacles(sl, center, RADIUS + 5);
        boolean cured = player.hasEffect(MobEffects.WITHER);
        if (cured) player.removeEffect(MobEffects.WITHER);

        if (blocks + animals + tentacles == 0 && !cured) {
            player.displayClientMessage(Component.translatable("message.skyfall.nothing_to_cleanse"), true);
            return InteractionResultHolder.fail(stack);
        }

        sl.playSound(null, center, ModSounds.CLEANSE.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
        sl.sendParticles(ParticleTypes.END_ROD, center.getX() + 0.5, center.getY() + 1.0, center.getZ() + 0.5,
                40, 2.0, 1.0, 2.0, 0.05);
        stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.skyfall.sky_repellent.tooltip").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.skyfall.sky_repellent.tooltip2").withStyle(ChatFormatting.DARK_GRAY));
    }
}
