package com.skyfall.client;

import com.skyfall.SkyfallMod;
import com.skyfall.entity.SkyNpcEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.resources.ResourceLocation;

/** SKY is drawn with the vanilla player model and her own skin. Her skin has wide (4px) arms. */
public class SkyNpcRenderer extends LivingEntityRenderer<SkyNpcEntity, PlayerModel<SkyNpcEntity>> {
    private static final boolean SLIM = false;
    private static final ResourceLocation SKIN = ResourceLocation.fromNamespaceAndPath(SkyfallMod.MODID, "textures/entity/sky.png");

    public SkyNpcRenderer(EntityRendererProvider.Context context) {
        super(context, new SkyModel(context.bakeLayer(SLIM ? ModelLayers.PLAYER_SLIM : ModelLayers.PLAYER), SLIM), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(SkyNpcEntity entity) {
        return SKIN;
    }
}
