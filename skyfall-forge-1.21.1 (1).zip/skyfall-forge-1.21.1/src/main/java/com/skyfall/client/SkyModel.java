package com.skyfall.client;

import com.skyfall.entity.SkyNpcEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * The player model with SKY's custom animations layered on top of the vanilla walk / head-look:
 *  IDLE    frantic: hands wringing at her chest, head snapping around, glancing up at the sky
 *  TALK    cold and rigid: one hand clutching her chest, the other making sharp little beats
 *  REACH   the free hand stretches out toward your shoulder, trembling
 *  GRABBED arms stretched toward you, then thrashing, legs kicking, head thrown back
 */
public class SkyModel extends PlayerModel<SkyNpcEntity> {

    public SkyModel(ModelPart root, boolean slim) {
        super(root, slim);
    }

    private static float noise(int n) {
        return Mth.frac(Mth.sin(n * 12.9898F) * 43758.547F);
    }

    private static float ease(float t) {
        t = Mth.clamp(t, 0.0F, 1.0F);
        return 1.0F - (1.0F - t) * (1.0F - t) * (1.0F - t);
    }

    @Override
    public void setupAnim(SkyNpcEntity e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);

        float st = e.getAnimTicks() + Mth.frac(ageInTicks);
        float walk = Mth.clamp(limbSwingAmount * 2.0F, 0.0F, 1.0F);      // 1 = running: keep vanilla arm swing
        float blend = Mth.clamp(st / 8.0F, 0.0F, 1.0F);                  // ease into each new pose

        switch (e.getState()) {
            case SkyNpcEntity.TALK -> talk(ageInTicks, blend * (1.0F - walk * 0.6F));
            case SkyNpcEntity.REACH -> reach(st, ageInTicks, blend * (1.0F - walk * 0.5F));
            case SkyNpcEntity.GRABBED -> grabbed(st);
            default -> idle(ageInTicks, walk);
        }

        // the overlay layers must follow the parts we just moved
        this.leftSleeve.copyFrom(this.leftArm);
        this.rightSleeve.copyFrom(this.rightArm);
        this.leftPants.copyFrom(this.leftLeg);
        this.rightPants.copyFrom(this.rightLeg);
        this.jacket.copyFrom(this.body);
        this.hat.copyFrom(this.head);
    }

    private static void pose(ModelPart part, float blend, float x, float y, float z) {
        part.xRot = Mth.lerp(blend, part.xRot, x);
        part.yRot = Mth.lerp(blend, part.yRot, y);
        part.zRot = Mth.lerp(blend, part.zRot, z);
    }

    /** Frantic: wringing hands, twitchy head. */
    private void idle(float f, float walk) {
        float blend = 1.0F - walk;
        pose(this.rightArm, blend, -1.05F + Mth.sin(f * 1.1F) * 0.12F, -0.55F, 0.05F);
        pose(this.leftArm, blend, -1.05F + Mth.cos(f * 1.3F) * 0.12F, 0.55F, -0.05F);

        int step = (int) (f * 0.3F);                                      // a new twitch every ~3 ticks
        this.head.yRot += (noise(step) - 0.5F) * 0.9F;
        this.head.xRot += (noise(step + 97) - 0.5F) * 0.5F;
        this.head.zRot = (noise(step + 7) - 0.5F) * 0.25F;
        if (((int) (f / 45.0F)) % 4 == 2) {                               // every few seconds: look up at the sky
            this.head.xRot = -0.8F + (noise(step + 31) - 0.5F) * 0.2F;
        }
    }

    /** Cold: nearly still, one hand at her chest, sharp beats with the other. */
    private void talk(float f, float blend) {
        float beat = Mth.sin(f * 0.5F);
        pose(this.rightArm, blend, -0.9F + beat * 0.35F, -0.35F, 0.1F);
        pose(this.leftArm, blend, -1.2F, 0.85F, 0.0F);
        this.head.zRot = 0.06F;
        int t = (int) f;
        if (t % 40 < 3) this.head.yRot += 0.35F * ((t / 40) % 2 == 0 ? 1.0F : -1.0F);   // a rare, sharp snap
    }

    /** Right hand out toward your shoulder (she stands about one arm's length away, facing you). */
    private void reach(float st, float f, float blend) {
        float r = ease(st / 20.0F);
        float tremble = Mth.sin(f * 2.3F) * 0.03F * r;
        pose(this.rightArm, blend, Mth.lerp(r, -0.9F, -1.52F) + tremble, Mth.lerp(r, -0.35F, -0.1F), Mth.lerp(r, 0.1F, 0.0F));
        pose(this.leftArm, blend, Mth.lerp(r, -1.2F, -0.7F), Mth.lerp(r, 0.85F, 0.35F), Mth.lerp(r, 0.0F, -0.15F));
        this.head.xRot += 0.05F;
    }

    /** Seized: first she reaches for you, then she thrashes. */
    private void grabbed(float st) {
        float toThrash = ease((st - 16.0F) / 10.0F);
        float s = st * 1.7F;

        float rx = Mth.lerp(toThrash, -1.55F, -2.6F + Mth.sin(s) * 0.7F);
        float rz = Mth.lerp(toThrash, 0.25F, 0.5F + Mth.sin(st * 2.1F) * 0.4F);
        float lx = Mth.lerp(toThrash, -1.55F, -2.6F + Mth.cos(s * 1.1F) * 0.7F);
        float lz = Mth.lerp(toThrash, -0.25F, -0.5F - Mth.cos(st * 2.3F) * 0.4F);
        pose(this.rightArm, 1.0F, rx, Mth.lerp(toThrash, -0.1F, 0.0F), rz);
        pose(this.leftArm, 1.0F, lx, Mth.lerp(toThrash, 0.1F, 0.0F), lz);

        float kick = Mth.sin(st * 1.5F) * 0.9F * toThrash;
        this.rightLeg.xRot = kick;
        this.leftLeg.xRot = -kick;
        this.rightLeg.zRot = 0.08F * toThrash;
        this.leftLeg.zRot = -0.08F * toThrash;
        this.head.xRot = Mth.lerp(toThrash, 0.0F, -0.55F + Mth.sin(st * 2.3F) * 0.3F);
        this.head.zRot = Mth.sin(st * 1.9F) * 0.2F * toThrash;
    }
}
