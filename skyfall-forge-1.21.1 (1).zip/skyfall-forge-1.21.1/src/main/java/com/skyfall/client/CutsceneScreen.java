package com.skyfall.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * An invisible, non-pausing screen. Opening a screen is the vanilla way to take movement and mouse-look away from
 * the player, and it lets us draw the letterbox bars, the subtitles and the fade-out on top of the world.
 */
public class CutsceneScreen extends Screen {
    public CutsceneScreen() {
        super(Component.empty());
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // keep the world fully visible
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        ClientCutscene.renderOverlay(graphics, this.font, this.width, this.height, partialTick);
    }
}
