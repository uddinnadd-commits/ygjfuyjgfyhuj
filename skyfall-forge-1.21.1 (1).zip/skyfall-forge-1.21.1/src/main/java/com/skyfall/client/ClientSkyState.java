package com.skyfall.client;

import com.skyfall.Phases;
import net.minecraft.Util;

/** Client-side mirror of the world's sky state. Only plain fields, so it is safe to load on a server too. */
public final class ClientSkyState {
    public static volatile int count;
    public static volatile long seed;
    /** Wall-clock millis when the newest hole started to open (or -1). */
    public static volatile long animStartMillis = -1L;

    public static void update(int newCount, long newSeed, boolean animate) {
        if (animate && newCount > count) {
            animStartMillis = Util.getMillis();
        } else if (!animate) {
            animStartMillis = -1L;
        }
        count = newCount;
        seed = newSeed;
    }

    public static void reset() {
        count = 0;
        seed = 0L;
        animStartMillis = -1L;
    }

    public static int phase() {
        return Phases.of(count);
    }

    private ClientSkyState() {}
}
