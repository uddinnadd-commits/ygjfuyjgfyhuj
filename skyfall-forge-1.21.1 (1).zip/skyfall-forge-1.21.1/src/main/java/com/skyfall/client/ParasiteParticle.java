package com.skyfall.client;

import com.skyfall.block.CorruptedBlock;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.state.BlockState;

/** A little parasite crawling around a tree trunk (it dies if the log it lives on disappears). */
public class ParasiteParticle extends TextureSheetParticle {
    private static int active;

    private final SpriteSet sprites;
    private final double cx, cz;
    private double angle;
    private final double angularSpeed;
    private double yy;
    private double vy;

    protected ParasiteParticle(ClientLevel level, double x, double y, double z, SpriteSet sprites) {
        super(level, x, y, z);
        this.sprites = sprites;
        this.cx = Math.floor(x) + 0.5D;
        this.cz = Math.floor(z) + 0.5D;
        this.yy = y;
        this.angle = this.random.nextDouble() * Math.PI * 2.0D;
        this.angularSpeed = (0.03D + this.random.nextDouble() * 0.04D) * (this.random.nextBoolean() ? 1 : -1);
        this.lifetime = 120 + this.random.nextInt(120);
        this.quadSize = 0.12F + this.random.nextFloat() * 0.06F;
        this.gravity = 0.0F;
        this.hasPhysics = false;
        this.setSprite(sprites.get(this.random));
        active++;
        place();
    }

    public static int active() {
        return active;
    }

    private void place() {
        double c = Math.cos(angle), s = Math.sin(angle);
        // rounded square path just outside the log's faces
        this.x = cx + Math.signum(c) * Math.pow(Math.abs(c), 0.25D) * 0.53D;
        this.z = cz + Math.signum(s) * Math.pow(Math.abs(s), 0.25D) * 0.53D;
        this.y = yy;
        this.setPos(this.x, this.y, this.z);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        angle += angularSpeed;
        yy += vy;
        if (this.random.nextInt(25) == 0) vy = (this.random.nextDouble() - 0.5D) * 0.06D;
        place();
        this.setSprite(sprites.get((this.age / 3) % 3, 2));

        BlockState st = this.level.getBlockState(BlockPos.containing(cx, yy, cz));
        boolean trunk = st.is(BlockTags.LOGS) || (st.getBlock() instanceof CorruptedBlock cb && cb.getKind() == CorruptedBlock.Kind.LOG);
        if (!trunk) this.remove();
    }

    @Override
    public void remove() {
        if (this.isAlive()) active--;
        super.remove();
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double xSpeed, double ySpeed, double zSpeed) {
            return new ParasiteParticle(level, x, y, z, sprites);
        }
    }
}
