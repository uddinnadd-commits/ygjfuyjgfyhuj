package com.skyfall.client;

import com.skyfall.Phases;
import com.skyfall.SkyfallMod;
import com.skyfall.block.CorruptedBlock;
import com.skyfall.registry.ModParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SkyfallMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {

    /** Draw the broken sky right after the vanilla sky. */
    @SubscribeEvent
    public static void onRenderStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.dimension() != Level.OVERWORLD) return;
        SkyHoleRenderer.render(event.getCamera(), event.getProjectionMatrix());
    }

    /** Phase 2+: parasites crawl around tree trunks near the player. */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent.Post event) {
        ClientCutscene.tick();
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.player == null || mc.isPaused()) return;
        if (level.dimension() != Level.OVERWORLD) return;
        int phase = ClientSkyState.phase();
        if (phase < 2) return;
        if (level.getGameTime() % 3L != 0L) return;
        if (ParasiteParticle.active() >= (phase >= 3 ? 70 : 28)) return;

        RandomSource r = level.random;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int i = 0; i < 20; i++) {
            pos.set(mc.player.getBlockX() + r.nextInt(41) - 20, mc.player.getBlockY() + r.nextInt(21) - 8, mc.player.getBlockZ() + r.nextInt(41) - 20);
            BlockState st = level.getBlockState(pos);
            boolean trunk = st.is(BlockTags.LOGS) || (st.getBlock() instanceof CorruptedBlock cb && cb.getKind() == CorruptedBlock.Kind.LOG);
            if (trunk) {
                level.addParticle(ModParticles.PARASITE.get(), pos.getX() + 0.5D, pos.getY() + r.nextDouble(), pos.getZ() + 0.5D, 0.0D, 0.0D, 0.0D);
                break;
            }
        }
    }

    /** Phase 2+: the horizon bleeds toward dark red. */
    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        int phase = ClientSkyState.phase();
        if (phase < 2) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.dimension() != Level.OVERWORLD) return;
        float k = phase >= 3 ? 0.55F : 0.25F;
        event.setRed(Mth.lerp(k, event.getRed(), 0.16F));
        event.setGreen(Mth.lerp(k, event.getGreen(), 0.01F));
        event.setBlue(Mth.lerp(k, event.getBlue(), 0.03F));
    }

    /** Cutscene: aim the camera at SKY (the player's real rotation is untouched). */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (ClientCutscene.isActive()) ClientCutscene.applyCamera(event);
    }

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        if (ClientCutscene.isActive()) event.setFOV(event.getFOV() * ClientCutscene.fovFactor());
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientCutscene.stop();
        ClientSkyState.reset();
    }

    private ClientForgeEvents() {}
}
