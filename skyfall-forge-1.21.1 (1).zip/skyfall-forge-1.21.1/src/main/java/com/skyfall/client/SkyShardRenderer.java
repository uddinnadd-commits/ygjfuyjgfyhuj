package com.skyfall.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.skyfall.SkyfallMod;
import com.skyfall.entity.SkyShardEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Renders a falling sky shard as a tumbling dark glass polygon with bright bevelled edges. */
public class SkyShardRenderer extends EntityRenderer<SkyShardEntity> {
    private static final ResourceLocation WHITE = ResourceLocation.fromNamespaceAndPath(SkyfallMod.MODID, "textures/entity/white.png");

    public SkyShardRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRender(SkyShardEntity entity, Frustum frustum, double camX, double camY, double camZ) {
        return true;
    }

    @Override
    public ResourceLocation getTextureLocation(SkyShardEntity entity) {
        return WHITE;
    }

    @Override
    public void render(SkyShardEntity entity, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
        ShardShape shape = ShardShape.of(entity.getShardSeed());
        float size = entity.getShardSize();
        float t = entity.tickCount + partialTick;

        ps.pushPose();
        ps.translate(0.0D, entity.getBbHeight() / 2.0D, 0.0D);
        ps.mulPose(Axis.YP.rotationDegrees(t * shape.spinY));
        ps.mulPose(Axis.XP.rotationDegrees(shape.tiltX + t * shape.spinX));
        ps.mulPose(Axis.ZP.rotationDegrees(shape.tiltZ + t * shape.spinZ));
        ps.scale(size, size, size);

        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(WHITE));
        PoseStack.Pose pose = ps.last();
        float h = shape.thickness * 0.5F;
        int n = shape.n;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            float sh = 0.12F + shape.shade[i] * 0.4F;                     // per-facet brightness -> cracked glass look
            float r = 0.03F + sh * 0.25F, g = 0.05F + sh * 0.35F, b = 0.12F + sh * 0.6F;
            // front + back facets (triangle fan from the centre, emitted as degenerate quads)
            quad(vc, pose, 0, 0, h, shape.xs[i], shape.ys[i], h, shape.xs[j], shape.ys[j], h, shape.xs[j], shape.ys[j], h, r, g, b, 0.88F, 0, 0, 1);
            quad(vc, pose, 0, 0, -h, shape.xs[j], shape.ys[j], -h, shape.xs[i], shape.ys[i], -h, shape.xs[i], shape.ys[i], -h, r, g, b, 0.88F, 0, 0, -1);
            // bright bevelled rim
            float ex = shape.ys[j] - shape.ys[i], ey = -(shape.xs[j] - shape.xs[i]);
            quad(vc, pose, shape.xs[i], shape.ys[i], h, shape.xs[j], shape.ys[j], h, shape.xs[j], shape.ys[j], -h, shape.xs[i], shape.ys[i], -h,
                    0.72F, 0.93F, 1.0F, 0.95F, ex, ey, 0);
        }
        ps.popPose();
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4,
                             float r, float g, float b, float a, float nx, float ny, float nz) {
        v(vc, pose, x1, y1, z1, r, g, b, a, nx, ny, nz);
        v(vc, pose, x2, y2, z2, r, g, b, a, nx, ny, nz);
        v(vc, pose, x3, y3, z3, r, g, b, a, nx, ny, nz);
        v(vc, pose, x4, y4, z4, r, g, b, a, nx, ny, nz);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z,
                          float r, float g, float b, float a, float nx, float ny, float nz) {
        vc.addVertex(pose, x, y, z).setColor(r, g, b, a).setUv(0.5F, 0.5F)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, nx, ny, nz);
    }
}
