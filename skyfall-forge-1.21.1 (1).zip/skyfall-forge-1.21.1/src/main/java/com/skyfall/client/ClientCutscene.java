package com.skyfall.client;

import com.skyfall.network.SkyCutscenePacket;
import com.skyfall.registry.ModSounds;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.ViewportEvent;

/**
 * Client half of SKY's cutscene: letterbox bars, typed subtitles with a little voice blip, a camera that tracks SKY
 * (it only changes the camera, never your real rotation), a slow push-in, a shock when the tentacle hits, and the
 * final fade to black. The server sends what happens when; this class just shows it.
 */
public final class ClientCutscene {
    private static final float CHARS_PER_TICK = 1.25F;

    private static boolean active;
    private static int skyId;
    private static int totalTicks;
    private static int lineIndex = -1;
    private static int lineTicks;
    private static int lastTyped;
    private static boolean cutoff;
    private static int cutoffChars;
    private static int cutoffTicks = -1;
    private static int fadeTicks = -1;
    private static float shake;
    private static float jolt;
    private static boolean prevHideGui;
    private static boolean camInit;
    private static float camYaw, camPitch;
    private static Vec3 lastSkyPos;

    public static boolean isActive() {
        return active;
    }

    public static void handle(int action, int entityId, int arg) {
        switch (action) {
            case SkyCutscenePacket.START -> start(entityId);
            case SkyCutscenePacket.LINE -> {
                lineIndex = arg;
                lineTicks = 0;
                lastTyped = 0;
                cutoff = false;
            }
            case SkyCutscenePacket.TOUCH -> jolt = 1.0F;
            case SkyCutscenePacket.CUTOFF -> {
                cutoffChars = currentTyped();
                cutoff = true;
                cutoffTicks = 0;
                shake = 1.0F;
            }
            case SkyCutscenePacket.FADE -> fadeTicks = 0;
            case SkyCutscenePacket.STOP -> stop();
            default -> { }
        }
    }

    private static void start(int id) {
        Minecraft mc = Minecraft.getInstance();
        active = true;
        skyId = id;
        totalTicks = 0;
        lineIndex = -1;
        lineTicks = 0;
        lastTyped = 0;
        cutoff = false;
        cutoffTicks = -1;
        fadeTicks = -1;
        shake = 0.0F;
        jolt = 0.0F;
        camInit = false;
        lastSkyPos = null;
        prevHideGui = mc.options.hideGui;
        mc.options.hideGui = true;
        mc.setScreen(new CutsceneScreen());
    }

    public static void stop() {
        if (!active) return;
        active = false;
        Minecraft mc = Minecraft.getInstance();
        mc.options.hideGui = prevHideGui;
        if (mc.screen instanceof CutsceneScreen) mc.setScreen(null);
    }

    public static void tick() {
        if (!active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            stop();
            return;
        }
        totalTicks++;
        lineTicks++;
        if (cutoffTicks >= 0) cutoffTicks++;
        if (fadeTicks >= 0) fadeTicks++;
        shake *= 0.94F;
        jolt *= 0.85F;

        if (lineIndex >= 0 && !cutoff) {                       // a cold little blip every few letters
            String text = lineText();
            int typed = currentTyped();
            if (typed > 0 && typed / 3 > lastTyped / 3 && text.charAt(typed - 1) != ' ') {
                Vec3 at = lastSkyPos != null ? lastSkyPos : mc.player.position();
                mc.level.playLocalSound(at.x, at.y, at.z, ModSounds.SKY_VOICE.get(), SoundSource.VOICE,
                        0.8F, 1.0F + (mc.level.random.nextFloat() - 0.5F) * 0.1F, false);
            }
            lastTyped = typed;
        }
        if (mc.screen == null) mc.setScreen(new CutsceneScreen());
        if (totalTicks > 20 * 75) stop();                      // failsafe: never trap the player
    }

    private static String lineText() {
        return Component.translatable("dialogue.skyfall.sky." + lineIndex).getString();
    }

    private static int currentTyped() {
        if (lineIndex < 0) return 0;
        return Math.min(lineText().length(), (int) (lineTicks * CHARS_PER_TICK));
    }

    /* ------------------------------------------------------------------ camera */

    public static void applyCamera(ViewportEvent.ComputeCameraAngles event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity sky = mc.level.getEntity(skyId);
        if (sky != null) lastSkyPos = sky.getPosition((float) event.getPartialTick()).add(0.0, 1.5, 0.0);
        if (lastSkyPos == null) return;

        Vec3 eye = event.getCamera().getPosition();
        double dx = lastSkyPos.x - eye.x, dy = lastSkyPos.y - eye.y, dz = lastSkyPos.z - eye.z;
        float targetYaw = (float) (Mth.atan2(dz, dx) * 57.29577951308232D) - 90.0F;
        float targetPitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 57.29577951308232D);
        if (!camInit) {
            camYaw = event.getYaw();
            camPitch = event.getPitch();
            camInit = true;
        }
        camYaw += Mth.wrapDegrees(targetYaw - camYaw) * 0.12F;
        camPitch += (targetPitch - camPitch) * 0.12F;

        float sy = 0.0F, sp = 0.0F;
        if (shake > 0.01F) {
            RandomSource r = mc.level.random;
            sy = (r.nextFloat() - 0.5F) * 6.0F * shake;
            sp = (r.nextFloat() - 0.5F) * 6.0F * shake;
        }
        sp -= jolt * 2.5F;                                     // a small flinch when her hand lands on your shoulder
        event.setYaw(camYaw + sy);
        event.setPitch(Mth.clamp(camPitch + sp, -90.0F, 90.0F));
    }

    public static float fovFactor() {
        float push = Mth.clamp(totalTicks / 340.0F, 0.0F, 1.0F) * 0.16F;           // slow, creeping zoom-in
        float shock = 0.0F;
        if (cutoffTicks >= 0) {                                                       // the tentacle hits: the world lurches wider
            shock = Mth.clamp(cutoffTicks / 8.0F, 0.0F, 1.0F) * 0.28F * Math.max(0.0F, 1.0F - cutoffTicks / 60.0F);
        }
        return 1.0F - push + shock;
    }

    /* ------------------------------------------------------------------ overlay */

    public static void renderOverlay(GuiGraphics g, Font font, int w, int h, float pt) {
        float open = Mth.clamp((totalTicks + pt) / 25.0F, 0.0F, 1.0F);
        int bar = (int) (h * 0.13F * (1.0F - (1.0F - open) * (1.0F - open)));
        g.fill(0, 0, w, bar, 0xFF000000);
        g.fill(0, h - bar, w, h, 0xFF000000);

        if (lineIndex >= 0 && (fadeTicks < 0 || fadeTicks < 30)) {
            String full = lineText();
            int n = cutoff ? Math.min(full.length(), cutoffChars)
                    : Math.min(full.length(), (int) ((lineTicks + pt) * CHARS_PER_TICK));
            String shown = full.substring(0, n) + (cutoff ? "\u2014" : "");
            int maxW = Math.min(w - 60, 360);
            List<FormattedCharSequence> lines = font.split(Component.literal(shown), maxW);
            int lineH = 11;
            int y = h - bar - 24 - lines.size() * lineH;
            int jx = cutoff && shake > 0.05F ? (int) ((Mth.sin(totalTicks * 7.0F)) * 2.0F * shake) : 0;
            g.drawCenteredString(font, Component.literal("SKY"), w / 2 + jx, y - 14, 0xFF9FD8FF);
            for (int i = 0; i < lines.size(); i++) {
                FormattedCharSequence line = lines.get(i);
                g.drawString(font, line, (w - font.width(line)) / 2 + jx, y + i * lineH, 0xFFE8E8F2, true);
            }
        }

        if (fadeTicks >= 0) {
            int alpha = (int) (Mth.clamp((fadeTicks + pt) / 40.0F, 0.0F, 1.0F) * 255.0F);
            g.fill(0, 0, w, h, alpha << 24);
        }
    }

    private ClientCutscene() {}
}
