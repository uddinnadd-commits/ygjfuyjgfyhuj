package com.skyfall.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.skyfall.SkyfallMod;
import com.skyfall.entity.SkyTentacleEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;

/** Draws the tentacle as a writhing six-sided tube from the entity (the tip) up along the sky direction. */
public class SkyTentacleRenderer extends EntityRenderer<SkyTentacleEntity> {
    private static final ResourceLocation TEX = ResourceLocation.fromNamespaceAndPath(SkyfallMod.MODID, "textures/entity/tentacle.png");
    private static final int NODES = 48;
    private static final int SIDES = 6;

    public SkyTentacleRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRender(SkyTentacleEntity entity, Frustum frustum, double camX, double camY, double camZ) {
        return true;
    }

    @Override
    public ResourceLocation getTextureLocation(SkyTentacleEntity entity) {
        return TEX;
    }

    @Override
    public void render(SkyTentacleEntity e, float yaw, float partialTick, PoseStack ps, MultiBufferSource buffers, int light) {
        Vec3 dir = e.getSkyDirection();
        float reach = e.getReach(partialTick);
        float time = (e.tickCount + partialTick) * 0.08F;

        // tip is at the entity; while extending, the visible tip is still up in the sky
        Vec3 anchor = dir.scale(SkyTentacleEntity.LENGTH);
        Vec3 tip = anchor.scale(1.0 - reach);

        // two vectors perpendicular to the rope for the waving
        Vec3 ref = Math.abs(dir.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 p1 = dir.cross(ref).normalize();
        Vec3 p2 = dir.cross(p1).normalize();

        float[][] pts = new float[NODES + 1][3];
        float[] rad = new float[NODES + 1];
        for (int i = 0; i <= NODES; i++) {
            float s = i / (float) NODES;                       // 0 = tip, 1 = anchor in the sky
            Vec3 base = tip.add(anchor.subtract(tip).scale(s));
            double amp = 1.8 * Math.sin(Math.PI * s) * reach;
            double writhe = (1.0 - s) * (1.0 - s) * 0.9;
            double a1 = Math.sin(time * 1.7 + s * 9.0) * amp + Math.sin(time * 3.1 + s * 5.0) * writhe;
            double a2 = Math.cos(time * 1.3 + s * 7.0) * amp + Math.cos(time * 2.7 + s * 6.0) * writhe;
            Vec3 pos = base.add(p1.scale(a1)).add(p2.scale(a2));
            pts[i][0] = (float) pos.x;
            pts[i][1] = (float) pos.y;
            pts[i][2] = (float) pos.z;
            rad[i] = 0.18F + 0.95F * (float) Math.pow(s, 1.3);
        }

        int packed = LightTexture.pack(Math.max(LightTexture.block(light), 6), Math.max(LightTexture.sky(light), 6));
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEX));
        PoseStack.Pose pose = ps.last();

        float[][][] ring = new float[NODES + 1][SIDES][3];
        float[][][] nrm = new float[NODES + 1][SIDES][3];
        for (int i = 0; i <= NODES; i++) {
            int a = Math.max(0, i - 1), b = Math.min(NODES, i + 1);
            Vec3 tangent = new Vec3(pts[b][0] - pts[a][0], pts[b][1] - pts[a][1], pts[b][2] - pts[a][2]).normalize();
            Vec3 r0 = Math.abs(tangent.x) < 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 0, 1);
            Vec3 u = tangent.cross(r0).normalize();
            Vec3 v = tangent.cross(u);
            for (int k = 0; k < SIDES; k++) {
                double ang = k * (Math.PI * 2.0 / SIDES);
                Vec3 out = u.scale(Math.cos(ang)).add(v.scale(Math.sin(ang)));
                ring[i][k][0] = pts[i][0] + (float) out.x * rad[i];
                ring[i][k][1] = pts[i][1] + (float) out.y * rad[i];
                ring[i][k][2] = pts[i][2] + (float) out.z * rad[i];
                nrm[i][k][0] = (float) out.x;
                nrm[i][k][1] = (float) out.y;
                nrm[i][k][2] = (float) out.z;
            }
        }
        for (int i = 0; i < NODES; i++) {
            float v0 = i / (float) NODES * 10.0F, v1 = (i + 1) / (float) NODES * 10.0F;
            for (int k = 0; k < SIDES; k++) {
                int k2 = (k + 1) % SIDES;
                float u0 = k / (float) SIDES, u1 = (k + 1) / (float) SIDES;
                vert(vc, pose, ring[i][k], u0, v0, packed, nrm[i][k]);
                vert(vc, pose, ring[i][k2], u1, v0, packed, nrm[i][k2]);
                vert(vc, pose, ring[i + 1][k2], u1, v1, packed, nrm[i + 1][k2]);
                vert(vc, pose, ring[i + 1][k], u0, v1, packed, nrm[i + 1][k]);
            }
        }
    }

    private static void vert(VertexConsumer vc, PoseStack.Pose pose, float[] p, float u, float v, int light, float[] n) {
        vc.addVertex(pose, p[0], p[1], p[2]).setColor(1.0F, 1.0F, 1.0F, 1.0F).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, n[0], n[1], n[2]);
    }
}
