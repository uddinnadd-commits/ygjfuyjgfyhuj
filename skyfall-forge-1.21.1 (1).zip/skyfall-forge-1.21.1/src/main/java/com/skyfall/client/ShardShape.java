package com.skyfall.client;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import net.minecraft.util.Mth;

/** A random star-shaped glass polygon (triangle up to a jagged 11-gon) derived from a seed. */
final class ShardShape {
    private static final Map<Integer, ShardShape> CACHE = new HashMap<>();

    final int n;
    final float[] xs, ys, shade;
    final float thickness;
    final float spinX, spinY, spinZ, tiltX, tiltZ;

    static ShardShape of(int seed) {
        if (CACHE.size() > 256) CACHE.clear();
        return CACHE.computeIfAbsent(seed, ShardShape::new);
    }

    private ShardShape(int seed) {
        Random r = new Random(seed * 0x9E3779B97F4A7C15L);
        r.nextInt();
        n = r.nextFloat() < 0.28F ? 3 : 4 + r.nextInt(8);
        xs = new float[n];
        ys = new float[n];
        shade = new float[n];
        float sx = 0.45F + r.nextFloat() * 0.55F;
        float sy = 0.8F + r.nextFloat() * 0.6F;
        for (int i = 0; i < n; i++) {
            float a = (float) ((i + (r.nextFloat() - 0.5F) * 0.7F) / n * Math.PI * 2.0);
            float rad = n == 3 ? 0.75F + r.nextFloat() * 0.25F : 0.35F + r.nextFloat() * 0.65F;
            if (n > 5 && r.nextFloat() < 0.22F) rad *= 1.7F;           // spike
            xs[i] = Mth.cos(a) * rad * sx;
            ys[i] = Mth.sin(a) * rad * sy;
            shade[i] = r.nextFloat();
        }
        thickness = 0.04F + r.nextFloat() * 0.05F;
        spinX = (r.nextFloat() - 0.5F) * 7.0F;
        spinY = (r.nextFloat() - 0.5F) * 9.0F;
        spinZ = (r.nextFloat() - 0.5F) * 5.0F;
        tiltX = r.nextFloat() * 360.0F;
        tiltZ = r.nextFloat() * 360.0F;
    }
}
