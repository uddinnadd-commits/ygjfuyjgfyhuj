package com.skyfall.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexSorting;
import com.skyfall.Phases;
import com.skyfall.SkyMath;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.Util;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

/**
 * Draws the broken sky: black void holes with jagged, glass-like outlines and cracks, one for every shard that has
 * fallen, drawn on a dome around the camera right after the vanilla sky (so terrain, clouds etc. cover them).
 * A dark red tint is added over the whole sky in phases 2 and 3.
 */
public final class SkyHoleRenderer {
    private static final double DIST = 90.0;
    private static final int MAX_HOLES = 140;

    private static final List<HoleShape> SHAPES = new ArrayList<>();
    private static long shapeSeed;

    /** Fixed, seed-derived geometry of one hole. Only the scale changes over time. */
    private static final class HoleShape {
        final Vec3 c, t1, t2;
        final float baseRadius;
        final int k;
        final float[] theta, rho;
        final int cracks;
        final int[] crackVertex;
        final float[] crackLen;
        final float[][] crackWob;

        HoleShape(long seed, int index) {
            c = SkyMath.holeDirection(seed, index);
            Vec3 up = Math.abs(c.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
            t1 = up.cross(c).normalize();
            t2 = c.cross(t1);
            Random r = new Random(seed ^ (index * 0x632BE59BD9B4E019L));
            r.nextInt();
            baseRadius = (float) Math.toRadians(5.0 + r.nextDouble() * 7.0);
            k = 12 + r.nextInt(11);
            theta = new float[k];
            rho = new float[k];
            for (int i = 0; i < k; i++) {
                theta[i] = (float) ((i + (r.nextDouble() - 0.5) * 0.7) / k * Math.PI * 2.0);
                float rr = (float) (0.5 + r.nextDouble() * 0.8);
                if (r.nextDouble() < 0.2) rr *= 1.9F;            // jagged spikes
                rho[i] = rr;
            }
            cracks = 3 + r.nextInt(5);
            crackVertex = new int[cracks];
            crackLen = new float[cracks];
            crackWob = new float[cracks][8];
            for (int i = 0; i < cracks; i++) {
                crackVertex[i] = r.nextInt(k);
                crackLen[i] = (float) (0.12 + r.nextDouble() * 0.33);
                float w = 0;
                for (int s = 0; s < 8; s++) {
                    w += (float) ((r.nextDouble() - 0.5) * 0.12);
                    crackWob[i][s] = w;
                }
            }
        }
    }

    public static void render(Camera camera, Matrix4f projection) {
        int count = ClientSkyState.count;
        if (count <= 0) return;
        long seed = ClientSkyState.seed;
        if (seed != shapeSeed || SHAPES.size() > count) {
            SHAPES.clear();
            shapeSeed = seed;
        }
        while (SHAPES.size() < count) SHAPES.add(new HoleShape(seed, SHAPES.size()));

        int phase = Phases.of(count);
        long nowMs = Util.getMillis();
        float time = (nowMs % 3_600_000L) / 1000.0F;
        float phaseScale = phase >= 3 ? 1.45F : phase == 2 ? 1.15F : 1.0F;

        // --- set our own camera-rotation-only view + the world projection, restore afterwards
        Matrix4f savedProjection = new Matrix4f(RenderSystem.getProjectionMatrix());
        Matrix4fStack modelView = RenderSystem.getModelViewStack();
        modelView.pushMatrix();
        modelView.identity();
        modelView.mul(new Matrix4f()
                .rotateX((float) Math.toRadians(camera.getXRot()))
                .rotateY((float) Math.toRadians(camera.getYRot() + 180.0F)));
        RenderSystem.applyModelViewMatrix();
        RenderSystem.setProjectionMatrix(projection, VertexSorting.DISTANCE_TO_ORIGIN);

        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

        BufferBuilder b = Tesselator.getInstance().begin(VertexFormat.Mode.TRIANGLES, DefaultVertexFormat.POSITION_COLOR);
        if (phase >= 2) drawTint(b, phase, time);
        int first = Math.max(0, count - MAX_HOLES);
        for (int i = first; i < count; i++) {
            float grow = 1.0F;
            if (i == count - 1 && ClientSkyState.animStartMillis > 0L) {
                float g = Mth.clamp((nowMs - ClientSkyState.animStartMillis) / 8000.0F, 0.0F, 1.0F);
                grow = Math.max(0.02F, 1.0F - (1.0F - g) * (1.0F - g) * (1.0F - g));
            }
            float size = grow * phaseScale * (1.0F + Math.min(1.0F, 0.04F * (count - 1 - i)));
            drawHole(b, SHAPES.get(i), size, time + i * 1.7F);
        }
        MeshData mesh = b.build();
        if (mesh != null) BufferUploader.drawWithShader(mesh);

        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        modelView.popMatrix();
        RenderSystem.applyModelViewMatrix();
        RenderSystem.setProjectionMatrix(savedProjection, VertexSorting.DISTANCE_TO_ORIGIN);
    }

    /* ------------------------------------------------------------------ geometry helpers */

    private static void vtx(BufferBuilder b, double[] p, float r, float g, float bl, float a) {
        b.addVertex((float) p[0], (float) p[1], (float) p[2]).setColor(r, g, bl, a);
    }

    /** Point on the sky dome at polar offset (theta, rho) around the hole centre. */
    private static void pt(HoleShape h, double theta, double rho, double[] out) {
        double ct = Math.cos(theta), st = Math.sin(theta), cr = Math.cos(rho), sr = Math.sin(rho);
        double x = h.c.x * cr + (h.t1.x * ct + h.t2.x * st) * sr;
        double y = h.c.y * cr + (h.t1.y * ct + h.t2.y * st) * sr;
        double z = h.c.z * cr + (h.t1.z * ct + h.t2.z * st) * sr;
        double len = Math.sqrt(x * x + y * y + z * z);
        out[0] = x / len * DIST;
        out[1] = y / len * DIST;
        out[2] = z / len * DIST;
    }

    private static void drawTint(BufferBuilder b, int phase, float time) {
        float a = phase >= 3 ? 0.36F + 0.05F * Mth.sin(time * 0.7F) : 0.20F;
        final int lat = 10, lon = 24;
        double[] p00 = new double[3], p01 = new double[3], p10 = new double[3], p11 = new double[3];
        for (int i = 0; i < lat; i++) {
            double e0 = Math.toRadians(-15.0 + 105.0 * i / lat);
            double e1 = Math.toRadians(-15.0 + 105.0 * (i + 1) / lat);
            for (int j = 0; j < lon; j++) {
                double a0 = Math.PI * 2.0 * j / lon, a1 = Math.PI * 2.0 * (j + 1) / lon;
                sph(e0, a0, p00);
                sph(e0, a1, p01);
                sph(e1, a0, p10);
                sph(e1, a1, p11);
                vtx(b, p00, 0.16F, 0.0F, 0.03F, a);
                vtx(b, p01, 0.16F, 0.0F, 0.03F, a);
                vtx(b, p11, 0.16F, 0.0F, 0.03F, a);
                vtx(b, p00, 0.16F, 0.0F, 0.03F, a);
                vtx(b, p11, 0.16F, 0.0F, 0.03F, a);
                vtx(b, p10, 0.16F, 0.0F, 0.03F, a);
            }
        }
    }

    private static void sph(double elevation, double azimuth, double[] out) {
        double ce = Math.cos(elevation);
        out[0] = ce * Math.cos(azimuth) * DIST;
        out[1] = Math.sin(elevation) * DIST;
        out[2] = ce * Math.sin(azimuth) * DIST;
    }

    private static void drawHole(BufferBuilder b, HoleShape h, float size, float t) {
        double radius = h.baseRadius * size;
        int k = h.k;
        double[][] inner = new double[k][3];
        double[][] outer = new double[k][3];
        for (int i = 0; i < k; i++) {
            pt(h, h.theta[i], h.rho[i] * radius, inner[i]);
            pt(h, h.theta[i], h.rho[i] * radius * 1.45 + 0.015 * size, outer[i]);
        }
        float pulse = 0.75F + 0.25F * Mth.sin(t * 1.9F);

        // 1) glowing dark-red rim that fades outward
        for (int i = 0; i < k; i++) {
            int j = (i + 1) % k;
            float ga = 0.6F * pulse;
            vtx(b, inner[i], 0.5F, 0.02F, 0.10F, ga);
            vtx(b, inner[j], 0.5F, 0.02F, 0.10F, ga);
            vtx(b, outer[j], 0.5F, 0.02F, 0.10F, 0.0F);
            vtx(b, inner[i], 0.5F, 0.02F, 0.10F, ga);
            vtx(b, outer[j], 0.5F, 0.02F, 0.10F, 0.0F);
            vtx(b, outer[i], 0.5F, 0.02F, 0.10F, 0.0F);
        }

        // 2) the void itself: a fan of pure black triangles
        double[] centre = {h.c.x * DIST, h.c.y * DIST, h.c.z * DIST};
        for (int i = 0; i < k; i++) {
            int j = (i + 1) % k;
            vtx(b, centre, 0.0F, 0.0F, 0.02F, 1.0F);
            vtx(b, inner[i], 0.0F, 0.0F, 0.0F, 1.0F);
            vtx(b, inner[j], 0.0F, 0.0F, 0.0F, 1.0F);
        }

        // 3) cracks running out of the spikes
        double[] pl = new double[3], pr = new double[3], nl = new double[3], nr = new double[3];
        final int segs = 7;
        for (int ci = 0; ci < h.cracks; ci++) {
            int vi = h.crackVertex[ci];
            double th0 = h.theta[vi];
            double rho0 = h.rho[vi] * radius * 0.97;
            double len = h.crackLen[ci] * size;
            double w0 = 0.006 * size + 0.002;
            double prevTh = th0, prevRho = rho0, prevW = w0;
            for (int s = 1; s <= segs; s++) {
                double f = s / (double) segs;
                double nth = th0 + h.crackWob[ci][s - 1];
                double nrho = rho0 + len * f;
                double nw = w0 * (1.0 - f * 0.85);
                pt(h, prevTh - prevW / prevRho, prevRho, pl);
                pt(h, prevTh + prevW / prevRho, prevRho, pr);
                pt(h, nth - nw / nrho, nrho, nl);
                pt(h, nth + nw / nrho, nrho, nr);
                float a0 = (float) (1.0 - (f - 1.0 / segs) * 0.85);
                float a1 = (float) (1.0 - f * 0.85);
                vtx(b, pl, 0, 0, 0, a0);
                vtx(b, pr, 0, 0, 0, a0);
                vtx(b, nl, 0, 0, 0, a1);
                vtx(b, pr, 0, 0, 0, a0);
                vtx(b, nr, 0, 0, 0, a1);
                vtx(b, nl, 0, 0, 0, a1);
                prevTh = nth;
                prevRho = nrho;
                prevW = nw;
            }
        }
    }

    private SkyHoleRenderer() {}
}
