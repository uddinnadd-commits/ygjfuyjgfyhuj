package com.skyfall.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.skyfall.Infection;
import com.skyfall.SkyfallMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * Draws dark stains over any parasite-infected animal, re-using the animal's own model.
 * Phase 2: light stains. Phase 3: heavy stains plus glowing red veins.
 */
public class StainLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation LIGHT = tex("stain_light");
    private static final ResourceLocation HEAVY = tex("stain_heavy");
    private static final ResourceLocation GLOW = tex("stain_glow");

    public StainLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(SkyfallMod.MODID, "textures/entity/" + name + ".png");
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, T entity, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible() || !Infection.isInfected(entity)) return;
        int phase = ClientSkyState.phase();

        VertexConsumer stain = buffers.getBuffer(RenderType.entityTranslucent(phase >= 3 ? HEAVY : LIGHT));
        this.getParentModel().renderToBuffer(ps, stain, light, LivingEntityRenderer.getOverlayCoords(entity, 0.0F), 0xFFFFFFFF);

        if (phase >= 3) {
            int alpha = 150 + (int) (100.0F * (0.5F + 0.5F * (float) Math.sin(ageInTicks * 0.18F)));
            VertexConsumer glow = buffers.getBuffer(RenderType.eyes(GLOW));
            this.getParentModel().renderToBuffer(ps, glow, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, (alpha << 24) | 0x00FFFFFF);
        }
    }
}
