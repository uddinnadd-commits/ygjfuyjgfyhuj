package com.skyfall.client;

import com.skyfall.SkyfallMod;
import com.skyfall.entity.SkyNpcEntity;
import com.skyfall.entity.SkyTentacleEntity;
import com.skyfall.registry.ModEntities;
import com.skyfall.registry.ModParticles;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Mod-bus events. Attribute registration is common (both sides); the rest is client only. */
public final class ClientModEvents {

    @Mod.EventBusSubscriber(modid = SkyfallMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Common {
        @SubscribeEvent
        public static void onAttributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.TENTACLE.get(), SkyTentacleEntity.createAttributes().build());
            event.put(ModEntities.SKY_NPC.get(), SkyNpcEntity.createAttributes().build());
        }
    }

    @Mod.EventBusSubscriber(modid = SkyfallMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class Client {
        @SubscribeEvent
        public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.SKY_SHARD.get(), SkyShardRenderer::new);
            event.registerEntityRenderer(ModEntities.TENTACLE.get(), SkyTentacleRenderer::new);
            event.registerEntityRenderer(ModEntities.SKY_NPC.get(), SkyNpcRenderer::new);
        }

        /** Every passive (CREATURE category) mob gets the stain layer; it only draws when the mob is infected. */
        @SuppressWarnings({"unchecked", "rawtypes"})
        @SubscribeEvent
        public static void onAddLayers(EntityRenderersEvent.AddLayers event) {
            for (EntityType<?> type : event.getEntityTypes()) {
                if (type.getCategory() != MobCategory.CREATURE) continue;
                Object renderer = event.getRenderer((EntityType) type);
                if (renderer instanceof LivingEntityRenderer living) {
                    living.addLayer(new StainLayer(living));
                }
            }
        }

        @SubscribeEvent
        public static void onRegisterParticles(RegisterParticleProvidersEvent event) {
            event.registerSpriteSet(ModParticles.PARASITE.get(), ParasiteParticle.Provider::new);
        }
    }

    private ClientModEvents() {}
}
