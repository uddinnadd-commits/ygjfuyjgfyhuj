package com.skyfall;

import net.minecraft.world.entity.LivingEntity;

/**
 * Infection flag for passive mobs.
 *
 * The flag is stored in the vanilla-synced "air supply" value: a land mob never has more than its max air,
 * so (air > maxAir) is free to mean "a parasite is controlling this one". Because it is a vanilla synced field
 * the client sees it without any extra packets, and it is saved with the entity.
 */
public final class Infection {
    private static final int BONUS = 7;
    public static final String CLEANSED_TAG = "skyfall_cleansed";

    public static boolean isInfected(LivingEntity e) {
        return e.getAirSupply() > e.getMaxAirSupply();
    }

    public static void setInfected(LivingEntity e, boolean infected) {
        if (infected) {
            if (!isInfected(e)) e.setAirSupply(e.getMaxAirSupply() + BONUS);
        } else if (isInfected(e)) {
            e.setAirSupply(e.getMaxAirSupply());
        }
    }

    public static boolean isImmune(LivingEntity e) {
        return e.getPersistentData().getBoolean(CLEANSED_TAG);
    }

    public static void makeImmune(LivingEntity e) {
        e.getPersistentData().putBoolean(CLEANSED_TAG, true);
    }

    private Infection() {}
}
