package com.skyfall.block;

import com.skyfall.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Remembers what the block was before it got corrupted, so the Sky Repellent can restore it exactly. */
public class CorruptedBlockEntity extends BlockEntity {
    private BlockState original = Blocks.AIR.defaultBlockState();

    public CorruptedBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CORRUPTED.get(), pos, state);
    }

    public BlockState getOriginal() {
        return original;
    }

    public void setOriginal(BlockState state) {
        this.original = state;
        this.setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("Original", NbtUtils.writeBlockState(original));
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("Original")) {
            original = NbtUtils.readBlockState(registries.lookupOrThrow(Registries.BLOCK), tag.getCompound("Original"));
        }
    }
}
