package com.skyfall.block;

import com.skyfall.Infection;
import com.skyfall.Phases;
import com.skyfall.SkyfallConfig;
import com.skyfall.entity.SkyTentacleEntity;
import com.skyfall.world.Corruption;
import com.skyfall.world.SkyfallManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * One class for all four parasite-corrupted blocks (ground / log / leaves / house material).
 * - touching it gives you Wither
 * - it slowly spreads in phase 3 (random ticks)
 * - it remembers the block it replaced so the Sky Repellent can restore it
 */
public class CorruptedBlock extends Block implements EntityBlock {
    public enum Kind { GROUND, LOG, LEAVES, FLESH }

    private final Kind kind;

    public CorruptedBlock(BlockBehaviour.Properties props, Kind kind) {
        super(props);
        this.kind = kind;
    }

    public Kind getKind() {
        return kind;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CorruptedBlockEntity(pos, state);
    }

    @Override
    public void stepOn(Level level, BlockPos pos, BlockState state, Entity entity) {
        super.stepOn(level, pos, state, entity);
        if (level.isClientSide || !(entity instanceof LivingEntity living)) return;
        if (living instanceof Player p && (p.isCreative() || p.isSpectator())) return;
        if (living instanceof SkyTentacleEntity || Infection.isInfected(living)) return;
        MobEffectInstance current = living.getEffect(MobEffects.WITHER);
        if (current == null || current.getDuration() < 40) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
        }
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        super.randomTick(state, level, pos, random);
        if (!SkyfallConfig.ENABLE_CORRUPTION.get()) return;
        if (Phases.of(SkyfallManager.shardCount()) < 3) return;
        for (int i = 0; i < 2; i++) {
            if (random.nextInt(3) != 0) continue;
            BlockPos target = pos.offset(random.nextInt(3) - 1, random.nextInt(3) - 1, random.nextInt(3) - 1);
            Corruption.tryCorrupt(level, target, true);
        }
    }

    /* Squishy: fleshy trunks and growth soften falls, and the canopy even bounces you a little. */
    @Override
    public void fallOn(Level level, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
        if (kind == Kind.LEAVES || kind == Kind.LOG) {
            entity.causeFallDamage(fallDistance, 0.35F, level.damageSources().fall());
        } else {
            super.fallOn(level, state, pos, entity, fallDistance);
        }
    }

    @Override
    public void updateEntityAfterFallOn(BlockGetter level, Entity entity) {
        if (kind == Kind.LEAVES && !entity.isSuppressingBounce()) {
            Vec3 v = entity.getDeltaMovement();
            if (v.y < 0.0D) {
                entity.setDeltaMovement(v.x, -v.y * 0.5D, v.z);
            }
        } else {
            super.updateEntityAfterFallOn(level, entity);
        }
    }
}
